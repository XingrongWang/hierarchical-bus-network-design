function [k_shortest_path,k_length_path]=Kshortest_path(A,weight,s,e,K)
k_shortest_path=cell(1,K);
k_length_path=zeros(1,K);
weight_temp=weight;
k=1;
while k<=K
    if k==1
        [k_shortest_path{1,k},k_length_path(1,k)]=shortest_path(A,weight_temp,s,e);
    else
        n_node=size(k_shortest_path{1,k-1}(1,:),2);
        if mod(n_node,2)==0
            weight_temp(k_shortest_path{1,k-1}(1,n_node/2),k_shortest_path{1,k-1}(1,n_node/2+1))=inf;
        else
            weight_temp(k_shortest_path{1,k-1}(1,(n_node+1)/2-1),k_shortest_path{1,k-1}(1,(n_node+1)/2))=inf;
        end
        [k_shortest_path{1,k},k_length_path(1,k)]=shortest_path(A,weight_temp,s,e);
    end
    k=k+1;
end
