function [line,length_line,time_line]=candidate_line
global road_matrix length_road_matrix
global N_platform
global K
global Lmin Lmax
global v_bus
line={};
length_line=[];
time_line=[];
for i=1:N_platform
    for j=i+1:N_platform
        [line_temp,length_line_temp]=Kshortest_path(road_matrix,length_road_matrix,i,j,K);
        for k=1:K
            if length_line_temp(1,k)<=Lmax&&length_line_temp(1,k)>=Lmin
                line=[line,line_temp{1,k}];
                length_line=[length_line,length_line_temp(1,k)];
                time_line=[time_line,length_line_temp(1,k)/v_bus];
            end
        end
    end
end
        



