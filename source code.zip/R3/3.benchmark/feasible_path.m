function [od_feasible_path,length_od_feasible_path]=feasible_path
global num_node
global road_matrix  length_road_matrix
od_feasible_path=cell(num_node,num_node);
length_od_feasible_path=zeros(num_node,num_node);
for i=1:num_node
    for j=1:num_node
        od_feasible_path{i,j}={};
        if j~=i
            [path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
            od_feasible_path{i,j}=path_temp;
            length_od_feasible_path(i,j)=length_path_temp;
        end
    end
end



