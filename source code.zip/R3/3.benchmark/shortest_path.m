function [shortest_path_temp,length_path_temp]=shortest_path(A,weight,s,e)
%注意输出的变量名不能和函数名同名，否则容易报错：等号右边的输出不足，不能够赋值
shortest_path_temp=[];
length_path_temp=0;
N_node=size(A,1);
K=N_node;
distance=zeros(K,N_node);
former_node=zeros(K,N_node);
recent_node=zeros(1,K);%临时标号
permanent_node=[];%永久标号
non_permanent_node=[1:N_node];%除永久标号之外的点
for k=1:K
    if k==1
        distance(k,s)=0;
        distance(k,1:s-1)=inf;
        distance(k,s+1:N_node)=inf;
        former_node(k,:)=s;
        recent_node(1,k)=s;
        permanent_node=[permanent_node,recent_node(1,k)];
        for j=1:size(permanent_node,2)
        non_permanent_node(find(non_permanent_node==permanent_node(1,j)))=[];
        end
    else
        position_adjcent=find(A(recent_node(1,k-1),:)==1);%从1开始标号的话，position既是顺序也是点!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!(多计算了已经标号的点)
        for i=1:size(position_adjcent,2)
            temp_distance=distance(k-1,recent_node(1,k-1))+weight(recent_node(1,k-1),position_adjcent(1,i));
            if temp_distance<distance(k-1,position_adjcent(1,i))%不变的话不更新，只有小于才更新
                former_node(k,position_adjcent(1,i))=recent_node(1,k-1);
                distance(k,position_adjcent(1,i))=temp_distance;
            else
                former_node(k,position_adjcent(1,i))=former_node(k-1,position_adjcent(1,i));
                distance(k,position_adjcent(1,i))=distance(k-1,position_adjcent(1,i));
            end
        end
        %position之外的点（包括已经获得永久标号的点，和没有获得标号的点）和上次迭代一样，距离和紧前节点保持一样
        position_non_adjcent=find(A(recent_node(1,k-1),:)==0);
        for i=1:size(position_non_adjcent,2)
            former_node(k,position_non_adjcent(1,i))=former_node(k-1,position_non_adjcent(1,i));
            distance(k,position_non_adjcent(1,i))=distance(k-1,position_non_adjcent(1,i));
        end
        %未标号的节点里面找最小值!!!!有可能有多个相同的最小值
        distance_temp=distance(k,:);
        distance_temp_temp=[];
        for i=1:size(non_permanent_node,2)
         distance_temp_temp=[distance_temp_temp, distance_temp(1,non_permanent_node(1,i))];
        end
        min_temp_distance=min(distance_temp_temp);
        min_temp_distance_position=find(distance_temp_temp==min_temp_distance);%要找到对应的节点
        recent_node(1,k)=non_permanent_node(1,min_temp_distance_position(1,1));
        permanent_node=[permanent_node,recent_node(1,k)];
        non_permanent_node(find(non_permanent_node==recent_node(1,k)))=[];
        if recent_node(1,k)==e
            k_temp=k;
            break
        end
    end
end                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
shortest_path_temp=[e];
a=e;
for k=k_temp:-1:1
    a=former_node(k,a);
    shortest_path_temp=[a,shortest_path_temp];
end
shortest_path_temp=unique(shortest_path_temp,'stable');
length_path_temp=distance(k_temp,e);

