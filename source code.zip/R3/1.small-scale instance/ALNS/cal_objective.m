function [objective,cost,total_travel_time,total_wait_time,total_invehicle_time,total_transfer_time,total_transfer_time_walk,total_transfer_time_penalty,fa1,fa2,fa3,fa4,bus_flow]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,current_bus_type,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty)
global cost_operation
global CAP_bus
global N_platform
global K
global Num_metro_line
global C_metro
global f_metro
global cost_max
global min_avg_load
new_metro_node=[];
for i=1:Num_metro_line
new_metro_node=[new_metro_node,new_total_line{1,i}];
end
Z0=0;
Z0_1=0;
Z0_2=0;
Z0_3=0;
Z1=0;
Z2=0;
Z3=0;
Z4=0;
total_transfer_time_walk=0;
total_transfer_time_penalty=0;
for s=1:N_platform
    for e=1:N_platform
        if s~=e          
            for k=1:K
                Z0=Z0+travel_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_1=Z0_1+wait_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_2=Z0_2+invehicle_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_3=Z0_3+transfer_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                total_transfer_time_walk=total_transfer_time_walk+OD_Kpath_demand{s,e}(1,k)*transfer_time_walk(s,e,k);
                total_transfer_time_penalty=total_transfer_time_penalty+OD_Kpath_demand{s,e}(1,k)*transfer_time_penalty(s,e,k);
            end
        end
    end
end

total_travel_time=Z0;
total_wait_time=Z0_1;
total_invehicle_time=Z0_2;
total_transfer_time=Z0_3;
%**************************************************************************
bus_metro_arc=cell(N_platform,N_platform);
bus_arc=cell(N_platform,N_platform);
for s=1:N_platform
    for e=1:N_platform
        if s~=e
            bus_metro_arc{s,e}=cell(1,K);
        end
    end
end
for s=1:N_platform
    for e=1:N_platform
        if s~=e           
            for k=1:K
                bus_metro_arc{s,e}{1,k}={};
                for i=1:size(invehicle_arc{s,e}{1,k},2)
                    if size(invehicle_arc{s,e}{1,k}{1,i},2)==2
                        bus_metro_arc{s,e}{1,k}=[bus_metro_arc{s,e}{1,k},invehicle_arc{s,e}{1,k}{1,i}];
                    else
                        for j=1:size(invehicle_arc{s,e}{1,k}{1,i},2)-1
                            bus_metro_arc{s,e}{1,k}=[bus_metro_arc{s,e}{1,k},[invehicle_arc{s,e}{1,k}{1,i}(1,j),invehicle_arc{s,e}{1,k}{1,i}(1,j+1)]];
                        end
                    end
                end
            end
        end
    end
end


for s=1:N_platform
    for e=1:N_platform
        if s~=e            
            for k=1:K
                bus_arc{s,e}{1,k}={};
                for j=1:size(bus_metro_arc{s,e}{1,k},2)
                    value=ismember(bus_metro_arc{s,e}{1,k}{1,j}(1,1),new_metro_node);
                    if value==0
                        bus_arc{s,e}{1,k}=[bus_arc{s,e}{1,k},bus_metro_arc{s,e}{1,k}{1,j}];
                    end
                end
            end
        end
    end
end


for s=1:N_platform
    for e=1:N_platform
        if s~=e      
            for k=1:K
                Z1=Z1+size(bus_arc{s,e}{1,k},2)*OD_Kpath_demand{s,e}(1,k)/size(bus_metro_arc{s,e}{1,k},2);
            end
        end
    end
end

bus_flow=Z1;           
                    
for j=1:Num_bus_line
    Z2=Z2+2*current_bus_frequency(1,j)*length_bus_line(1,j)*cost_operation(1,current_bus_type(1,j));
end
cost=Z2;

for i=1:Num_bus_line
    if route_demand_max(1,i+Num_metro_line)>current_bus_frequency(1,i)*CAP_bus(1,current_bus_type(1,i))
    Z3=Z3+99999999999*(route_demand_max(1,i+Num_metro_line)-current_bus_frequency(1,i)*CAP_bus(1,current_bus_type(1,i)));
    end
end
for i=1:Num_metro_line
    if  route_demand_max(1,i)>f_metro*C_metro
     Z3=Z3+99999999999*max((route_demand_max(1,i)-f_metro*C_metro),0);
    end
end
for i=1:Num_bus_line
    if current_N_bus(1,i)>N_bus_max(1,i)
    Z4=Z4+99999999999*max((current_N_bus(1,i)-N_bus_max(1,i)),0);
    end
end
avg_load=zeros(1,Num_bus_line);
for i=1:Num_bus_line
    avg_load(1,i)=(sum(route_demand1{1,i+Num_metro_line})+sum(route_demand2{1,i+Num_metro_line}))/(2*current_bus_frequency(1,i)*CAP_bus(1,current_bus_type(1,i))*(size(new_total_line{1,i+Num_metro_line},2)-1));
end
Z5=0;
for i=1:Num_bus_line
Z5=Z5+999999999999*max(min_avg_load-avg_load(1,i),0);
end
fa1=Z3;
fa2=Z4;
fa3=99999999999*max(Z2-cost_max,0);
fa4=Z5;
objective=Z0+Z3+Z4+Z5+fa3;