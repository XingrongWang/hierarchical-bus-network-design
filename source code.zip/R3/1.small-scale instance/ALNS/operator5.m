function [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator5(currentbest_bus_line)
global N_platform
global Max_trunk_line
global Max_main_line
global Max_feeder_line
global trunk_matrix
global main_feeder_matrix
global length_trunk_matrix
global length_main_feeder_matrix
global Metro_station
global KK
global currentbest_OD_Kpath_set currentbest_original_line currentbest_inline_transfer currentbest_arc_transfer currentbest_Num_transfer currentbest_invehicle_arc currentbest_invehicle_arc_line
global OD
value_update=0;
trunk_line=currentbest_bus_line{1,1};
main_line=currentbest_bus_line{1,2};
feeder_line=currentbest_bus_line{1,3};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
delete_line=[];
if num_trunk_line>0
    delete_line=[delete_line,1];
end
if num_main_line>0
    delete_line=[delete_line,2];
end
if num_feeder_line>0
    delete_line=[delete_line,3];
end
if size(delete_line,2)==0
    new_trunk_line=trunk_line;
    new_main_line=main_line;
    new_feeder_line=feeder_line;
    new_OD_Kpath_set=currentbest_OD_Kpath_set;
    new_original_line=currentbest_original_line;
    new_inline_transfer=currentbest_inline_transfer;
    new_arc_transfer=currentbest_arc_transfer;
    new_Num_transfer=currentbest_Num_transfer;
    new_invehicle_arc=currentbest_invehicle_arc;
    new_invehicle_arc_line=currentbest_invehicle_arc_line;
    value_update=0;
else
    delete_position=ceil(rand*size(delete_line,2));
    delete_kind=delete_line(1,delete_position);
    if delete_kind==1
        n=ceil(rand*num_trunk_line);
        trunk_line={trunk_line{1,1:n-1},trunk_line{1,n+1:num_trunk_line}};
    else
        if delete_kind==2
            n=ceil(rand*num_main_line);
            main_line={main_line{1,1:n-1},main_line{1,n+1:num_main_line}};
        else
            if delete_kind==3
                n=ceil(rand*num_feeder_line);
                feeder_line={feeder_line{1,1:n-1},feeder_line{1,n+1:num_feeder_line}};
            end
        end
    end
end
currentbest_bus_line_temp={trunk_line,main_line,feeder_line};
[Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
add_line=[];
if num_trunk_line<Max_trunk_line
    add_line=[add_line,1];
end
if num_main_line<Max_main_line
    add_line=[add_line,2];
end
if num_feeder_line<Max_feeder_line
    add_line=[add_line,3];
end
add_position=ceil(rand*size(add_line,2));
add_kind=add_line(1,add_position);
demand=[];
for i=1:N_platform
    demand=[demand,max(sum(OD(i,:)),sum(OD(:,i)))];
end
all_station=[1:N_platform];
vec=randperm(size(all_station,2));
s=all_station(1,vec(1,1));
rest=setdiff([1:N_platform],s);
rest_temp=randperm(size(rest,2));
if add_kind==1
    for j=1:size(rest,2)
        e=rest(1,rest_temp(1,j));
        [add_path_temp,length_path_temp]=Kshortest_line(trunk_matrix,length_trunk_matrix,s,e);
        for k=1:KK
            value2=judge2(length_path_temp(1,k),add_kind);
            value7=judge_trunk(add_path_temp{1,k});
            if value2==1&&value7==1
                bus_line_temp=add_path_temp{1,k};
                break
            end
        end
        if value2==1&&value7==1
            break
        end
    end
    if value2==0||value7==0
        bus_line_temp=[];
    end
else
    if add_kind==2
        for j=1:size(rest,2)
            e=rest(1,rest_temp(1,j));
            [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
            for k=1:KK
                value2=judge2(length_path_temp(1,k),add_kind);
                value8=judge_main_feeder(add_path_temp{1,k});
                if value2==1&&value8==1
                    bus_line_temp=add_path_temp{1,k};
                    break
                end
            end
            if value2==1&&value8==1
                break
            end
        end
        if value2==0||value8==0
            bus_line_temp=[];
        end
    else
        if add_kind==3
            s=Metro_station(1,ceil(rand*size(Metro_station,2)));
            vector=[1:N_platform];
            vector(vector==s)=[];
            rest_temp=randperm(size(vector,2));
            for i=1:size(vector,2)
                e=vector(1,rest_temp(1,i));
                [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
                for k=1:KK
                    value2=judge2(length_path_temp(1,k),add_kind);
                    value8=judge_main_feeder(add_path_temp{1,k});
                    if value2==1&&value8==1
                        bus_line_temp=add_path_temp{1,k};
                        break
                    end
                end
                if value2==1&&value8==1
                    break
                end
            end
            if value2==0||value8==0
                bus_line_temp=[];
            end
        end
    end
end
if size(bus_line_temp,2)>0
    if add_kind==1
        trunk_line=[trunk_line,bus_line_temp];
    else
        if add_kind==2
            main_line=[main_line,bus_line_temp];
        else
            if add_kind==3
                feeder_line=[feeder_line,bus_line_temp];
            end
        end
    end
end
value3=judge3(bus_line_temp,currentbest_bus_line_temp,add_kind);
[value5,plat_line_bus]=judge5(trunk_line,main_line,feeder_line);
value_update=0;
if value3==1&&value5==1
    [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
    [OD_Kpath_set_temp,original_line_temp,inline_transfer_temp,arc_transfer_temp,Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);
    value_temp1=ones(N_platform,N_platform);
    for s=1:N_platform
        for e=s+1:N_platform
            if ismember(inf,OD_Kpath_set_temp{s,e}{1,1})
                value_temp1(s,e)=0;
            end
        end
    end
    if ismember(0,value_temp1)
        value6=0;
    else
        value6=1;
    end
    if value6==1
        new_trunk_line=trunk_line;
        new_main_line=main_line;
        new_feeder_line=feeder_line;
        new_OD_Kpath_set=OD_Kpath_set_temp;
        new_original_line=original_line_temp;
        new_inline_transfer=inline_transfer_temp;
        new_arc_transfer=arc_transfer_temp;
        new_Num_transfer=Num_transfer_temp;
        new_invehicle_arc=invehicle_arc_temp;
        new_invehicle_arc_line=invehicle_arc_line_temp;
        value_update=1;
    else
        new_trunk_line=currentbest_bus_line{1,1};
        new_main_line=currentbest_bus_line{1,2};
        new_feeder_line=currentbest_bus_line{1,3};
        new_OD_Kpath_set=currentbest_OD_Kpath_set; 
        new_original_line=currentbest_original_line; 
        new_inline_transfer=currentbest_inline_transfer;
        new_arc_transfer=currentbest_arc_transfer;
        new_Num_transfer=currentbest_Num_transfer;
        new_invehicle_arc=currentbest_invehicle_arc; 
        new_invehicle_arc_line=currentbest_invehicle_arc_line;
    end
else
    new_trunk_line=currentbest_bus_line{1,1};
    new_main_line=currentbest_bus_line{1,2};
    new_feeder_line=currentbest_bus_line{1,3};
    new_OD_Kpath_set=currentbest_OD_Kpath_set;
    new_original_line=currentbest_original_line;
    new_inline_transfer=currentbest_inline_transfer;
    new_arc_transfer=currentbest_arc_transfer;
    new_Num_transfer=currentbest_Num_transfer;
    new_invehicle_arc=currentbest_invehicle_arc;
    new_invehicle_arc_line=currentbest_invehicle_arc_line;
end
new_num_trunk_line=size(new_trunk_line,2);
new_num_main_line=size(new_main_line,2);
new_num_feeder_line=size(new_feeder_line,2);
new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;

