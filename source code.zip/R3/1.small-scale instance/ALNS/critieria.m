global Num_metro_line
global C_metro
global f_metro
global CAP_bus
Num_bus_line=6;
bus_line={[2,3,4,5],[6,7,3,11],[9,8,4,12],[1,6,7,8],[10,3,8,9],[10,11,12,13,14]};
[Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line]=update_bimodal_network(Num_bus_line,bus_line);
[OD_Kpath_set,original_line,inline_transfer,arc_transfer,Num_transfer,invehicle_arc,invehicle_arc_line]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line);
[objective,cost,travel_time,fa1,fa2,Num_bus,bus_frequency,bus_type,Max_route_demand]=final(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer);    
metro_loading=zeros(1,Num_metro_line);
bus_loading=zeros(1,Num_bus_line);
for i=1:Num_metro_line
metro_loading(1,i)=Max_route_demand(1,i)/(C_metro*f_metro);
end
for i=1:Num_bus_line
bus_loading(1,i)=Max_route_demand(1,i+Num_metro_line)/(bus_frequency(1,i)*CAP_bus(1,bus_type(1,i)));
end
max_metro_loading=max(metro_loading);
max_bus_loading=max(bus_loading);
