function [value6,infeasible_od1,infeasible_od2,plat_line]=judge6(trunk_line,main_line,feeder_line)
global N_platform
shortest_path_temp=cell(N_platform,N_platform);
time_shortest_path_temp=zeros(N_platform,N_platform);
infeasible_od1={};
infeasible_od2={};
value_temp1=ones(N_platform,N_platform);
[Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
for s=1:N_platform
    for e=s+1:N_platform
        [k_shortest_path,k_time_path,original_line_temp,inline_transfer_temp,arc_transfer_temp,Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=Kshortest_path(new_bimodal_network,Time_new_bimodal_network,s,e,Num_total_line,new_total_line,plat_line,total_line,plat_line_node);
        if ismember(inf,k_time_path)
            value_temp1(s,e)=0;
            infeasible_od1=[infeasible_od1,[s,e]];
            infeasible_od2=[infeasible_od2,[s,e]];
        end
    end
end
if ismember(0,value_temp1)
    value6=0;
else
    value6=1;
end





