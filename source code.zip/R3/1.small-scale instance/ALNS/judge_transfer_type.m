function [total_num_transfer_type,time_total_num_transfer_type,sum_time_total_num_transfer_type]=judge_transfer_type(OD_Kpath_demand,Num_transfer,arc_transfer,Num_total_line,new_total_line)
global N_platform
global K
global Num_metro_line
num_transfer_type=cell(N_platform,N_platform);
temp=[];
for o=1:N_platform
    for d=1:N_platform
        num_od_transfer_type=zeros(1,11);
        if d~=o
            for k=1:K
                od_transfer_type=zeros(1,11);
                %*******************************
                if Num_transfer(o,d,k)==0
                    od_transfer_type(1,1)=1;
                else
                    if Num_transfer(o,d,k)==1
                        value1=arc_transfer{o,d}{1,k}(1,1);
                        value2=arc_transfer{o,d}{1,k}(1,2);
                        for i=1:Num_total_line
                            if ismember(value1, new_total_line{1,i})
                                line_value1=i;
                            end
                            if ismember(value2, new_total_line{1,i})
                                line_value2=i;
                            end
                        end
                        if line_value1>Num_metro_line&&line_value2>Num_metro_line
                            od_transfer_type(1,2)=1;
                        else
                            if line_value1<=Num_metro_line&&line_value2<=Num_metro_line
                            od_transfer_type(1,3)=1;
                            else
                                od_transfer_type(1,4)=1;
                            end
                        end
                    else
                        value1=arc_transfer{o,d}{1,k}(1,1);
                        value2=arc_transfer{o,d}{1,k}(1,2);
                        value4=arc_transfer{o,d}{1,k}(2,2);
                        for i=1:Num_total_line
                            if ismember(value1, new_total_line{1,i})
                                line_value1=i;
                            end
                            if ismember(value2, new_total_line{1,i})
                                line_value2=i;
                            end
                            if ismember(value4, new_total_line{1,i})
                                line_value4=i;
                            end
                        end
                        if line_value1>Num_metro_line&&line_value2>Num_metro_line&&line_value4>Num_metro_line
                            od_transfer_type(1,5)=1;
                        else
                            if line_value1>Num_metro_line&&line_value2>Num_metro_line&&line_value4<=Num_metro_line
                                od_transfer_type(1,6)=1;
                            else
                                if line_value1>Num_metro_line&&line_value2<=Num_metro_line&&line_value4>Num_metro_line
                                    od_transfer_type(1,7)=1;
                                else
                                    if line_value1>Num_metro_line&&line_value2<=Num_metro_line&&line_value4<=Num_metro_line
                                        od_transfer_type(1,8)=1;
                                    else
                                        if line_value1<=Num_metro_line&&line_value2<=Num_metro_line&&line_value4<=Num_metro_line
                                            od_transfer_type(1,9)=1;
                                        else
                                            if line_value1<=Num_metro_line&&line_value2<=Num_metro_line&&line_value4>Num_metro_line
                                                od_transfer_type(1,10)=1;
                                            else
                                               if line_value1<=Num_metro_line&&line_value2>Num_metro_line&&line_value4>Num_metro_line
                                                   od_transfer_type(1,11)=1;
                                               end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                for i=1:11
                    if od_transfer_type(1,i)==1
                        num_od_transfer_type(1,i)=num_od_transfer_type(1,i)+OD_Kpath_demand{o,d}(1,k);
                    end
                end
                if od_transfer_type(1,8)==1
                    temp=[temp,o,d];
                end
            end%k
            num_transfer_type{o,d}=num_od_transfer_type;
        end
    end
end

 total_num_transfer_type =zeros(1,11);
 for i=1:11
     for o=1:N_platform
         for d=1:N_platform
             if d~=o
                 total_num_transfer_type(1,i)=total_num_transfer_type(1,i)+num_transfer_type{o,d}(1,i);
             end
         end
     end
 end
 transfer_time1=0;
 transfer_time2=2.6;
 transfer_time3=3.36;
 transfer_time4=4.4;
 transfer_time5=2.6+2.6;
 transfer_time6=2.6+4.4;
 transfer_time7=4.4+4.4;
 transfer_time8=4.4+3.36;
 transfer_time9=3.36+3.36;
 transfer_time10=3.36+4.4;
 transfer_time11=4.4+2.6;
 transfer_time_temp=[transfer_time1,transfer_time2,transfer_time3,transfer_time4,transfer_time5,transfer_time6,transfer_time7,transfer_time8,transfer_time9,transfer_time10,transfer_time11];
 time_total_num_transfer_type=zeros(1,11);
 for i=1:11
     time_total_num_transfer_type(1,i)=total_num_transfer_type(1,i)*transfer_time_temp(1,i);
 end
 sum_time_total_num_transfer_type=sum(time_total_num_transfer_type);