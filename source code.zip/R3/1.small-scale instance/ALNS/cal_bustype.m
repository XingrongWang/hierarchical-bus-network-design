 function current_bus_type=cal_bustype(Num_bus_line,route_demand_max,current_bus_frequency)
 global CAP_bus
 global Num_bus_type
 global Num_metro_line
 current_bus_type=zeros(1,Num_bus_line);
 for j=1:Num_bus_line
     if (route_demand_max(1,j+Num_metro_line)/current_bus_frequency(1,j))>=CAP_bus(1,Num_bus_type)
         current_bus_type(1,j)=Num_bus_type;
     else
         if (route_demand_max(1,j+Num_metro_line)/current_bus_frequency(1,j))<=CAP_bus(1,1)
             current_bus_type(1,j)=1;
         else
             for g=1:Num_bus_type-1
                 if  (route_demand_max(1,j+Num_metro_line)/current_bus_frequency(1,j))<=CAP_bus(1,g+1)&&(route_demand_max(1,j+Num_metro_line)/current_bus_frequency(1,j))>CAP_bus(1,g)
                     current_bus_type(1,j)=g+1;
                 end
             end
         end
     end
 end