function [total_travel_time,total_wait_time,total_invehicle_time,total_transfer_time,total_transfer_time_walk,total_transfer_time_penalty]=cal_OD_objective(new_total_line,OD_Kpath_demand,travel_time,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty)
global N_platform
global K
global Num_metro_line
new_metro_node=[];
for i=1:Num_metro_line
new_metro_node=[new_metro_node,new_total_line{1,i}];
end
Z0=zeros(N_platform,N_platform);
Z0_1=zeros(N_platform,N_platform);
Z0_2=zeros(N_platform,N_platform);
Z0_3=zeros(N_platform,N_platform);
total_transfer_time_walk=zeros(N_platform,N_platform);
total_transfer_time_penalty=zeros(N_platform,N_platform);
for s=1:N_platform
    for e=1:N_platform
        if s~=e          
            for k=1:K
                Z0(s,e)=Z0(s,e)+travel_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_1(s,e)=Z0_1(s,e)+wait_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_2(s,e)=Z0_2(s,e)+invehicle_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_3(s,e)=Z0_3(s,e)+transfer_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                total_transfer_time_walk(s,e)=total_transfer_time_walk(s,e)+OD_Kpath_demand{s,e}(1,k)*transfer_time_walk(s,e,k);
                total_transfer_time_penalty(s,e)=total_transfer_time_penalty(s,e)+OD_Kpath_demand{s,e}(1,k)*transfer_time_penalty(s,e,k);
            end
        end
    end
end

total_travel_time=Z0;
total_wait_time=Z0_1;
total_invehicle_time=Z0_2;
total_transfer_time=Z0_3;

