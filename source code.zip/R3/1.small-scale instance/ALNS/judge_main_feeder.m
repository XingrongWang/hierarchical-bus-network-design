function value=judge_main_feeder(bus_line)
global road_matrix
global length_road_matrix
inter_node=[];
for g=1:size(bus_line,2)-1
    i=bus_line(1,g);
    j=bus_line(1,g+1);
    [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
    inter_node=[inter_node,shortest_path_temp(1,2:size(shortest_path_temp,2)-1)];
end
actual_route=[bus_line,inter_node];
actual_route_temp=unique(actual_route);
value_temp=size(actual_route,2)-size(actual_route_temp,2);
if value_temp==0
    value=1;
else
    value=0;
end