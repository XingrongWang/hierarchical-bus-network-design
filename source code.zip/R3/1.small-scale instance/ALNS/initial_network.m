function [trunk_line,main_line,feeder_line,Num_bus_line]=initial_network
trunk_line={};
main_line={[1,3,12,11,14,15,22,21],[6,5,4,11,10,9,8,7],[4,5,9,8,7,18,16,10],[2,6,8,16,17,19,15,22,21],[6,5,10,15,22,21,20],[1,3,12,11,14,23,24,13],[2,6,5,4,11,14,23,24]};
feeder_line={};

num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
Num_bus_line=num_trunk_line+num_main_line+num_feeder_line;