function [Objective,Cost,Total_travel_time,Total_wait_time,Total_invehicle_time,Total_transfer_time,Total_transfer_time_walk,Total_transfer_time_penalty,Fa1,Fa2,Fa3,Fa4,Num_bus,Bus_frequency,Bus_type,Bus_flow]=cal_objective_frequency_type(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer)
global N_bus
global Fmin
global Fmax
N_bus_min=zeros(1,Num_bus_line);
N_bus_max=zeros(1,Num_bus_line);
current_N_bus=zeros(1,Num_bus_line);
current_bus_frequency=zeros(1,Num_bus_line);
for i=1:Num_bus_line
    N_bus_min(1,i)=ceil(Fmin*2*time_bus_line(1,i));
    N_bus_max(1,i)=ceil(Fmax*2*time_bus_line(1,i));
end
GG=1;
N_min_total=sum(N_bus_min(1,:));
N_max_total=min(N_bus,sum(N_bus_max(1,:)));
G=N_max_total-N_min_total;
Best_objective=zeros(1,GG);
Best_bus_frequency=cell(1,GG);
Best_bus_type=cell(1,GG);
Best_N_bus=cell(1,GG);
Best_cost=zeros(1,GG);
Best_total_travel_time=zeros(1,GG);
Best_total_wait_time=zeros(1,GG);
Best_total_invehicle_time=zeros(1,GG);
Best_total_transfer_time=zeros(1,GG);
Best_total_transfer_time_walk=zeros(1,GG);
Best_total_transfer_time_penalty=zeros(1,GG);
Best_fa1=zeros(1,GG);
Best_fa2=zeros(1,GG);
Best_fa3=zeros(1,GG);
Best_fa4=zeros(1,GG);
Best_bus_flow=zeros(1,GG);
for g=1:GG
    N_bus_total=N_min_total+g-GG+G;
    for j=1:Num_bus_line
        current_N_bus(1,j)=N_bus_min(1,j);
    end
    rest_N_bus=N_bus_total-sum(current_N_bus);
    j=1;
    while rest_N_bus>0
        if current_N_bus(1,j)<N_bus_max(1,j)
            current_N_bus(1,j)=current_N_bus(1,j)+1;
            rest_N_bus=rest_N_bus-1;
            j=j+1;
        else
            j=j+1;
        end
        if j==Num_bus_line+1
            j=1;
        end
    end
    for j=1:Num_bus_line
        current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
    end
    [utility,travel_time,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty]=cal_utility(Num_total_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer,current_bus_frequency);        
    [OD_Kpath_demand,route_demand_max,route_demand1,route_demand2]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
    current_bus_type=cal_bustype(Num_bus_line,route_demand_max,current_bus_frequency);
    [best_objective,best_cost,best_total_travel_time,best_total_wait_time,best_total_invehicle_time,best_total_transfer_time,best_total_transfer_time_walk,best_total_transfer_time_penalty,best_fa1,best_fa2,best_fa3,best_fa4,best_bus_flow]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,current_bus_type,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty);
    best_bus_frequency=current_bus_frequency;
    best_bus_type=current_bus_type;
    best_N_bus=current_N_bus;
    increase_node=ones(Num_bus_line,Num_bus_line);
    for i=1:Num_bus_line
        increase_node(i,i)=0;
    end
    i=1;
    while i<=Num_bus_line
        if  current_N_bus(1,i)>N_bus_min(1,i)
            j=1;
            while j<=Num_bus_line 
                if increase_node(i,j)>=1
                    current_N_bus(1,i)=current_N_bus(1,i)-1;
                    current_N_bus(1,j)=current_N_bus(1,j)+1;
                    if current_N_bus(1,i)<N_bus_min(1,i)
                        current_N_bus(1,i)=current_N_bus(1,i)+1;
                        current_N_bus(1,j)=current_N_bus(1,j)-1;
                        i=i+1;
                        break
                    else
                        if current_N_bus(1,j)>N_bus_max(1,j)
                            current_N_bus(1,i)=current_N_bus(1,i)+1;
                            current_N_bus(1,j)=current_N_bus(1,j)-1;
                            j=j+1;
                        else
                            current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                            current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                            [utility,travel_time,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty]=cal_utility(Num_total_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer,current_bus_frequency);        
                            [OD_Kpath_demand,route_demand_max,route_demand1,route_demand2]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
                            current_bus_type=cal_bustype(Num_bus_line,route_demand_max,current_bus_frequency);
                            [objective,cost,total_travel_time,total_wait_time,total_invehicle_time,total_transfer_time,total_transfer_time_walk,total_transfer_time_penalty,fa1,fa2,fa3,fa4,bus_flow]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,current_bus_type,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty);
                            if objective<best_objective
                                best_objective=objective;
                                best_bus_frequency=current_bus_frequency;
                                best_bus_type=current_bus_type;
                                best_N_bus=current_N_bus;
                                best_cost=cost;
                                best_total_travel_time=total_travel_time;
                                best_total_wait_time=total_wait_time;
                                best_total_invehicle_time=total_invehicle_time;
                                best_total_transfer_time=total_transfer_time;
                                best_total_transfer_time_walk=total_transfer_time_walk;
                                best_total_transfer_time_penalty=total_transfer_time_penalty;
                                best_fa1=fa1;
                                best_fa2=fa2;
                                best_fa3=fa3;
                                best_fa4=fa4;
                                best_bus_flow=bus_flow;
                                increase_node(i,j)=increase_node(i,j)+1;
                                increase_node(j,i)=increase_node(j,i)-1;
                            else
                                increase_node(j,i)=increase_node(j,i)-1;
                                current_N_bus(1,i)=current_N_bus(1,i)+1;
                                current_N_bus(1,j)=current_N_bus(1,j)-1;
                                current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                                current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                                j=j+1;
                            end
                        end
                    end%end if
                else%%if increase_node(i,j)>=1
                    j=j+1;
                end%if increase_node(i,j)>=1
            end%while j
            i=i+1;
            %****************************************
        else
            i=i+1;
        end%if
    end%while i
    %***************************************************************************************8
    Best_objective(1,g)=best_objective;
    Best_bus_frequency{1,g}=best_bus_frequency;
    Best_bus_type{1,g}=best_bus_type;
    Best_N_bus{1,g}=best_N_bus;
    Best_cost(1,g)=best_cost;
    Best_total_travel_time(1,g)=best_total_travel_time;
    Best_total_wait_time(1,g)=best_total_wait_time;
    Best_total_invehicle_time(1,g)=best_total_invehicle_time;
    Best_total_transfer_time(1,g)=best_total_transfer_time;
    Best_total_transfer_time_walk(1,g)=best_total_transfer_time_walk;
    Best_total_transfer_time_penalty(1,g)=best_total_transfer_time_penalty;
    Best_fa1(1,g)=best_fa1;
    Best_fa2(1,g)=best_fa2;
    Best_fa3(1,g)=best_fa3;
    Best_fa4(1,g)=best_fa4;
    Best_bus_flow(1,g)=best_bus_flow;
end%g
% toc
min_position=find(Best_objective==min(Best_objective));
if size(min_position,2)>1
    min_position=min_position(1,1);
end
Objective=Best_objective(1,min_position);
Cost=Best_cost(1,min_position);
Total_travel_time=Best_total_travel_time(1,min_position);
Total_wait_time=Best_total_wait_time(1,min_position);
Total_invehicle_time=Best_total_invehicle_time(1,min_position);
Total_transfer_time=Best_total_transfer_time(1,min_position);
Total_transfer_time_walk=Best_total_transfer_time_walk(1,min_position);
Total_transfer_time_penalty=Best_total_transfer_time_penalty(1,min_position);
Fa1=Best_fa1(1,min_position);
Fa2=Best_fa2(1,min_position);
Fa3=Best_fa3(1,min_position);
Fa4=Best_fa4(1,min_position);
Num_bus=Best_N_bus{1,min_position};
Bus_frequency=Best_bus_frequency{1,min_position};
Bus_type=Best_bus_type{1,min_position};
Bus_flow=Best_bus_flow(1,min_position);
