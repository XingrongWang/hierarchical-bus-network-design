function [utility,travel_time,wait_time,invehicle_time,transfer_time,transfer_time_walk,transfer_time_penalty]=cal_utility(Num_total_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer,bus_frequency)
global N_platform
global K
global VOT
global Num_metro_line
global transfer_penalty
global f_metro
global dwell_time
utility=zeros(N_platform,N_platform,K);
travel_time=zeros(N_platform,N_platform,K);
fee=zeros(N_platform,N_platform,K);
for s=1:N_platform
    for e=1:N_platform
        if s~=e
            for k=1:K
                for i=1:size(invehicle_arc{s,e}{1,k},2)
                    length_invehicle_arc=0;
                    fee_arc=0;
                    for j=1:size(invehicle_arc{s,e}{1,k}{1,i},2)-1
                        length_invehicle_arc=length_invehicle_arc+Length_new_bimodal_network(invehicle_arc{s,e}{1,k}{1,i}(1,j),invehicle_arc{s,e}{1,k}{1,i}(1,j+1));
                    end
                    line_position=invehicle_arc_line{s,e}{1,k}(i,1);
                    if ismember(line_position,[1:Num_metro_line])
                        if length_invehicle_arc<=6
                            fee_arc=3;
                        else
                            if length_invehicle_arc>6&&length_invehicle_arc<=12
                                fee_arc=4;
                            else
                                if length_invehicle_arc>12&&length_invehicle_arc<=22
                                    fee_arc=5;
                                else
                                    if length_invehicle_arc>22&&length_invehicle_arc<=32
                                        fee_arc=6;
                                    else
                                        fee_arc=6+ceil((length_invehicle_arc-32)/20);
                                    end
                                end
                            end
                        end
                    else
                        if length_invehicle_arc<=10
                            fee_arc=2;
                        else
                            fee_arc=2+ceil((length_invehicle_arc-10)/5);
                        end
                    end
                    fee(s,e,k)=fee(s,e,k)+fee_arc;
                end
            end
        end
    end
end
network_frequency=zeros(1,Num_total_line);
wait_time=zeros(N_platform,N_platform,K);
wait_time1=zeros(N_platform,N_platform,K);
wait_time2=zeros(N_platform,N_platform,K);
for i=1:Num_total_line
    if ismember(i,[1:Num_metro_line])
        network_frequency(1,i)=f_metro;
    else
        network_frequency(1,i)=bus_frequency(1,i-Num_metro_line);
    end
end
for s=1:N_platform
    for e=1:N_platform
        if s~=e
            for k=1:K
                wait_time1(s,e,k)=60/(2*network_frequency(1,original_line(s,e,k)));
                for i=1:size(inline_transfer{s,e}{1,k},1)
                    wait_time2(s,e,k)=wait_time2(s,e,k)+60/(2*network_frequency(1,inline_transfer{s,e}{1,k}(i,1)));
                end
                wait_time(s,e,k)=wait_time1(s,e,k)+wait_time2(s,e,k);
            end
        end
    end
end

invehicle_time1=zeros(N_platform,N_platform,K);
station_dwell_time=zeros(N_platform,N_platform,K);
invehicle_time=zeros(N_platform,N_platform,K);
for s=1:N_platform
    for e=1:N_platform
        if s~=e           
            for k=1:K
                for i=1:size(invehicle_arc{s,e}{1,k},2)
                    for j=1:size(invehicle_arc{s,e}{1,k}{1,i},2)-1
                        invehicle_time1(s,e,k)=invehicle_time1(s,e,k)+Time_new_bimodal_network(invehicle_arc{s,e}{1,k}{1,i}(1,j),invehicle_arc{s,e}{1,k}{1,i}(1,j+1));
                    end
                    station_dwell_time(s,e,k)=station_dwell_time(s,e,k)+(size(invehicle_arc{s,e}{1,k}{1,i},2)-2)*dwell_time;
                end
            end
        end
    end
end

for s=1:N_platform
    for e=1:N_platform
        if s~=e   
            for k=1:K
                invehicle_time1(s,e,k)=60*invehicle_time1(s,e,k);
                station_dwell_time(s,e,k)=60*station_dwell_time(s,e,k);
                invehicle_time(s,e,k)=invehicle_time1(s,e,k)+station_dwell_time(s,e,k);
            end
        end
    end
end
transfer_time=zeros(N_platform,N_platform,K);
transfer_time_walk=zeros(N_platform,N_platform,K);
transfer_time_penalty=zeros(N_platform,N_platform,K);
for s=1:N_platform
    for e=1:N_platform
        if s~=e
            for k=1:K
                for i=1:size(arc_transfer{s,e}{1,k},1)
                    transfer_time_walk(s,e,k)=transfer_time_walk(s,e,k)+Time_new_bimodal_network(arc_transfer{s,e}{1,k}(i,1),arc_transfer{s,e}{1,k}(i,2));
                end
                transfer_time_walk(s,e,k)=transfer_time_walk(s,e,k)*60;
                if Num_transfer(s,e,k)~=0
                    for i=1:size(invehicle_arc_line{s,e}{1,k},1)-1
                        if ismember(invehicle_arc_line{s,e}{1,k}(i,1),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line{s,e}{1,k}(i+1,1),[1:Num_metro_line])
                            transfer_time_penalty(s,e,k)=transfer_time_penalty(s,e,k)+transfer_penalty(1,1);
                        else
                            if ismember(invehicle_arc_line{s,e}{1,k}(i,1),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line{s,e}{1,k}(i+1,1),[Num_metro_line+1:Num_total_line])
                                transfer_time_penalty(s,e,k)=transfer_time_penalty(s,e,k)+transfer_penalty(1,2);
                            else
                                if ismember(invehicle_arc_line{s,e}{1,k}(i,1),[1:Num_metro_line])&&ismember(invehicle_arc_line{s,e}{1,k}(i+1,1),[1:Num_metro_line]) 
                                    transfer_time_penalty(s,e,k)=transfer_time_penalty(s,e,k)+transfer_penalty(1,3);
                                else
                                    if ismember(invehicle_arc_line{s,e}{1,k}(i,1),[1:Num_metro_line])&&ismember(invehicle_arc_line{s,e}{1,k}(i+1,1),[Num_metro_line+1:Num_total_line])
                                        transfer_time_penalty(s,e,k)=transfer_time_penalty(s,e,k)+transfer_penalty(1,4);
                                    end
                                end
                            end
                        end
                    end
                end
                transfer_time(s,e,k)=transfer_time_walk(s,e,k)+transfer_time_penalty(s,e,k);
            end
        end
    end
end
for s=1:N_platform
    for e=1:N_platform
        if s~=e
            for k=1:K
                utility(s,e,k)=VOT*(wait_time(s,e,k)+invehicle_time1(s,e,k)+transfer_time(s,e,k)+station_dwell_time(s,e,k))+fee(s,e,k);
                travel_time(s,e,k)=wait_time(s,e,k)+invehicle_time1(s,e,k)+transfer_time(s,e,k)+station_dwell_time(s,e,k);
            end
        end
    end
end