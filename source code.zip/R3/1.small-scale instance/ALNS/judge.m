function value=judge(shortest_path_temp,length_shortest_path_temp,currentbest_num_bus_line,currentbest_bus_line)
global Length_max
global N_platform
global Max_arc_line
value=1;
if length_shortest_path_temp>Length_max
    value=0;
else
    value_temp=zeros(1,2*currentbest_num_bus_line);
    for n=1:currentbest_num_bus_line
        value_temp1=ismember(shortest_path_temp,currentbest_bus_line{1,n});
        if all(value_temp1==1)
            value_temp(1,n)=1;
        end
        value_temp2=ismember(currentbest_bus_line{1,n},shortest_path_temp);
        if all(value_temp2==1)
            value_temp(1,currentbest_num_bus_line+n)=1;
        end
    end
    if ismember(1,value_temp)
        value=0;
    else
        Num_bus_line=currentbest_num_bus_line+1;
        bus_line=[currentbest_bus_line,shortest_path_temp];
        [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line]=update_bimodal_network(Num_bus_line,bus_line);
        time_temp=zeros(N_platform,N_platform);
        for s=1:N_platform
            for e=1:N_platform
                if s~=e
                    [shortest_path_temp,time_path_temp]=shortest_path(new_bimodal_network,Time_new_bimodal_network,s,e);
                    time_temp(s,e)=time_path_temp;
                end
            end
        end
        if ismember(inf,time_temp)
            value=0;
        else
            for i=1:N_platform
                if size(plat_line{1,i},2)>Max_arc_line
                    value=0;
                end
            end
        end
    end
end





