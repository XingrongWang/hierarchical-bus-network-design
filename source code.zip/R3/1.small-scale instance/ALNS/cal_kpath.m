function [OD_Kpath_set,original_line,inline_transfer,arc_transfer,Num_transfer,invehicle_arc,invehicle_arc_line]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node)
global N_platform
global K
OD_Kpath_set=cell(N_platform,N_platform);
original_line=zeros(N_platform,N_platform,K);
arc_transfer=cell(N_platform,N_platform);
inline_transfer=cell(N_platform,N_platform);
Num_transfer=zeros(N_platform,N_platform,K);
invehicle_arc=cell(N_platform,N_platform);
invehicle_arc_line=cell(N_platform,N_platform);

%****************************************************************************************************
for s=1:N_platform
    for e=s+1:N_platform
            [k_shortest_path,k_time_path,original_line_temp,inline_transfer{s,e},arc_transfer{s,e},Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=Kshortest_path(new_bimodal_network,Time_new_bimodal_network,s,e,Num_total_line,new_total_line,plat_line,total_line,plat_line_node);
            OD_Kpath_set{s,e}=[k_time_path,k_shortest_path];
            original_line(s,e,:)=original_line_temp;
            Num_transfer(s,e,:)=Num_transfer_temp;
            invehicle_arc{s,e}=invehicle_arc_temp;
            invehicle_arc_line{s,e}=invehicle_arc_line_temp;
    end
end

for e=1:N_platform
    for s=e+1:N_platform
        OD_Kpath_set{s,e}{1,1}=OD_Kpath_set{e,s}{1,1};
        for k=1:K
            OD_Kpath_set{s,e}{1,1+k}=fliplr(OD_Kpath_set{e,s}{1,k+1});
            k_shortest_path{1,k}=OD_Kpath_set{s,e}{1,1+k};
            if OD_Kpath_set{s,e}{1,1}(1,k)~=inf
            [original_line_temp_temp,inline_transfer_temp_temp,arc_transfer_temp_temp,Num_transfer_temp_temp,invehicle_arc_temp_temp,invehicle_arc_line_temp_temp]=calculate_path_attribute(k_shortest_path{1,k},Num_total_line,new_total_line);
            original_line(s,e,k)=original_line_temp_temp;
            Num_transfer(s,e,k)=Num_transfer_temp_temp;
            invehicle_arc{s,e}{1,k}=invehicle_arc_temp_temp;
            invehicle_arc_line{s,e}{1,k}=invehicle_arc_line_temp_temp;
            inline_transfer{s,e}{1,k}=inline_transfer_temp_temp;
            arc_transfer{s,e}{1,k}=arc_transfer_temp_temp;
            else
                original_line(s,e,k)=0;
                Num_transfer_temp(s,e,k)=0;
                invehicle_arc_temp{s,e}{1,k}={};
                invehicle_arc_line_temp{s,e}{1,k}=[];
                inline_transfer_temp{s,e}{1,k}=[];
                arc_transfer_temp{s,e}{1,k}=[];
            end
        end
    end
end
