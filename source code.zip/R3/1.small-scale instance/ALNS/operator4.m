function [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator4(currentbest_bus_line)
global length_trunk_matrix
global length_main_feeder_matrix
global Min_length_trunk
global Min_length_main
global Min_length_feeder
global N_platform
global currentbest_OD_Kpath_set currentbest_original_line currentbest_inline_transfer currentbest_arc_transfer currentbest_Num_transfer currentbest_invehicle_arc currentbest_invehicle_arc_line
value_update=0;
trunk_line=currentbest_bus_line{1,1};
main_line=currentbest_bus_line{1,2};
feeder_line=currentbest_bus_line{1,3};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
delete_line=[];
if num_trunk_line>0
    delete_line=[delete_line,1];
end
if num_main_line>0
    delete_line=[delete_line,2];
end
if num_feeder_line>0
    delete_line=[delete_line,3];
end
if size(delete_line,2)==0
    new_trunk_line=trunk_line;
    new_main_line=main_line;
    new_feeder_line=feeder_line;
    new_OD_Kpath_set=currentbest_OD_Kpath_set;
    new_original_line=currentbest_original_line;
    new_inline_transfer=currentbest_inline_transfer;
    new_arc_transfer=currentbest_arc_transfer;
    new_Num_transfer=currentbest_Num_transfer;
    new_invehicle_arc=currentbest_invehicle_arc;
    new_invehicle_arc_line=currentbest_invehicle_arc_line;
    value_update=0;
else
    delete_kind=delete_line(1,ceil(rand*size(delete_line,2)));
    if delete_kind==1
        n1=ceil(rand*num_trunk_line);
        n2=round(rand);
        bus_line_temp=trunk_line{1,n1};
        length_bus_line_temp=0;
        for i=1:size(bus_line_temp,2)-1
            length_bus_line_temp=length_bus_line_temp+length_trunk_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
        end
        if n2==0
            delete_node_set=[];
            length=zeros(1,size(bus_line_temp,2)-1);
            for i=1:size(bus_line_temp,2)-1
                if i==1
                    length(1,i)=length_bus_line_temp-length_trunk_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
                else
                    length(1,i)=length(1,i-1)-length_trunk_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
                end
                if length(1,i)>=Min_length_trunk
                    delete_node_set=[delete_node_set,i];
                end
            end
            if size(delete_node_set,2)==0
                bus_line_temp=bus_line_temp;
            else
                delete_node_position=ceil(rand*size(delete_node_set,2));
                delete_node=delete_node_set(1,delete_node_position);
                bus_line_temp=bus_line_temp(1,delete_node+1:size(bus_line_temp,2));
            end
        else
            delete_node_set=[];
            length=zeros(1,size(bus_line_temp,2)-1);
            for i=size(bus_line_temp,2):-1:2
                if i==size(bus_line_temp,2)
                    length(1,i)=length_bus_line_temp-length_trunk_matrix(bus_line_temp(1,i),bus_line_temp(1,i-1));
                else
                    length(1,i)=length(1,i+1)-length_trunk_matrix(bus_line_temp(1,i),bus_line_temp(1,i-1));
                end
                if length(1,i)>=Min_length_trunk
                    delete_node_set=[delete_node_set,i];
                end
            end
            if size(delete_node_set,2)==0
                bus_line_temp=bus_line_temp;
            else
                delete_node_position=ceil(rand*size(delete_node_set,2));
                delete_node=delete_node_set(1,delete_node_position);
                bus_line_temp=bus_line_temp(1,1:delete_node-1);
            end
        end
    else
        if delete_kind==2
            n1=ceil(rand*num_main_line);
            n2=round(rand);
            bus_line_temp=main_line{1,n1};
            length_bus_line_temp=0;
            for i=1:size(bus_line_temp,2)-1
                length_bus_line_temp=length_bus_line_temp+length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
            end
            if n2==0
                delete_node_set=[];
                length=zeros(1,size(bus_line_temp,2));
                for i=1:size(bus_line_temp,2)-1
                    if i==1
                        length(1,i)=length_bus_line_temp-length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
                    else
                        length(1,i)=length(1,i-1)-length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
                    end
                    if length(1,i)>=Min_length_main
                        delete_node_set=[delete_node_set,i];
                    end
                end
                if size(delete_node_set,2)==0
                    bus_line_temp=bus_line_temp;
                else
                    delete_node_position=ceil(rand*size(delete_node_set,2));
                    delete_node=delete_node_set(1,delete_node_position);
                    bus_line_temp=bus_line_temp(1,delete_node+1:size(bus_line_temp,2));
                end
            else
                delete_node_set=[];
                length=zeros(1,size(bus_line_temp,2))-1;
                for i=size(bus_line_temp,2):-1:2
                    if i==size(bus_line_temp,2)
                        length(1,i)=length_bus_line_temp-length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i-1));
                    else
                        length(1,i)=length(1,i+1)-length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i-1));
                    end
                    if length(1,i)>=Min_length_main
                        delete_node_set=[delete_node_set,i];
                    end
                end
                if size(delete_node_set,2)==0
                    bus_line_temp=bus_line_temp;
                else
                    delete_node_position=ceil(rand*size(delete_node_set,2));
                    delete_node=delete_node_set(1,delete_node_position);
                    bus_line_temp=bus_line_temp(1,1:delete_node-1);
                end
            end
        else
            if delete_kind==3
                n1=ceil(rand*num_feeder_line);
                bus_line_temp=feeder_line{1,n1};
                length_bus_line_temp=0;
                for i=1:size(bus_line_temp,2)-1
                    length_bus_line_temp=length_bus_line_temp+length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i+1));
                end
                delete_node_set=[];
                length=zeros(1,size(bus_line_temp,2))-1;
                for i=size(bus_line_temp,2):-1:2
                    if i==size(bus_line_temp,2)
                        length(1,i)=length_bus_line_temp-length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i-1));
                    else
                        length(1,i)=length(1,i+1)-length_main_feeder_matrix(bus_line_temp(1,i),bus_line_temp(1,i-1));
                    end
                    if length(1,i)>=Min_length_feeder
                        delete_node_set=[delete_node_set,i];
                    end
                end
                if size(delete_node_set,2)==0
                    bus_line_temp=bus_line_temp;
                else
                    delete_node_position=ceil(rand*size(delete_node_set,2));
                    delete_node=delete_node_set(1,delete_node_position);
                    bus_line_temp=bus_line_temp(1,1:delete_node-1);
                end
            end
        end
    end
    if delete_kind==1
        trunk_line{1,n1}=bus_line_temp;
    else
        if delete_kind==2
            main_line{1,n1}=bus_line_temp;
        else
            if delete_kind==3
                feeder_line{1,n1}=bus_line_temp;
            end
        end
    end
    currentbest_bus_line_temp=currentbest_bus_line;
    currentbest_bus_line_temp{1,delete_kind}={currentbest_bus_line{1,delete_kind}{1,1:n1-1},currentbest_bus_line{1,delete_kind}{1,n1+1:size(currentbest_bus_line{1,delete_kind},2)}};
    value3=judge3(bus_line_temp,currentbest_bus_line_temp,delete_kind);
    [value5,plat_line_bus]=judge5(trunk_line,main_line,feeder_line);
    if value3==1&&value5==1 
    [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
    [OD_Kpath_set_temp,original_line_temp,inline_transfer_temp,arc_transfer_temp,Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);
    value_temp1=ones(N_platform,N_platform);
    for s=1:N_platform
        for e=s+1:N_platform
            if ismember(inf,OD_Kpath_set_temp{s,e}{1,1})
                value_temp1(s,e)=0;
            end
        end
    end
    if ismember(0,value_temp1)
        value6=0;
    else
        value6=1;
    end
    if value6==1
        new_trunk_line=trunk_line;
        new_main_line=main_line;
        new_feeder_line=feeder_line;
        new_OD_Kpath_set=OD_Kpath_set_temp;
        new_original_line=original_line_temp;
        new_inline_transfer=inline_transfer_temp;
        new_arc_transfer=arc_transfer_temp;
        new_Num_transfer=Num_transfer_temp;
        new_invehicle_arc=invehicle_arc_temp;
        new_invehicle_arc_line=invehicle_arc_line_temp;
        value_update=1;
    else
        new_trunk_line=currentbest_bus_line{1,1};
        new_main_line=currentbest_bus_line{1,2};
        new_feeder_line=currentbest_bus_line{1,3};
        new_OD_Kpath_set=currentbest_OD_Kpath_set;
        new_original_line=currentbest_original_line;
        new_inline_transfer=currentbest_inline_transfer;
        new_arc_transfer=currentbest_arc_transfer;
        new_Num_transfer=currentbest_Num_transfer;
        new_invehicle_arc=currentbest_invehicle_arc;
        new_invehicle_arc_line=currentbest_invehicle_arc_line;
        value_update=0;
    end
    else
        new_trunk_line=currentbest_bus_line{1,1};
        new_main_line=currentbest_bus_line{1,2};
        new_feeder_line=currentbest_bus_line{1,3};
        new_OD_Kpath_set=currentbest_OD_Kpath_set;
        new_original_line=currentbest_original_line;
        new_inline_transfer=currentbest_inline_transfer;
        new_arc_transfer=currentbest_arc_transfer;
        new_Num_transfer=currentbest_Num_transfer;
        new_invehicle_arc=currentbest_invehicle_arc;
        new_invehicle_arc_line=currentbest_invehicle_arc_line;
        value_update=0;
    end
end
new_num_trunk_line=size(new_trunk_line,2);
new_num_main_line=size(new_main_line,2);
new_num_feeder_line=size(new_feeder_line,2);
new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;