function value=judge_transfer(Num_transfer,invehicle_arc_line,Num_total_line)
global Num_metro_line
value=0;
temp=unique(invehicle_arc_line);
if size(temp,1)==size(invehicle_arc_line,1)
    temp_value=1;
else
    temp_value=0;
end
if Num_transfer<2&&temp_value==1
    value=1;
else
    if (ismember(invehicle_arc_line(1,1),[1:Num_metro_line])&&ismember(invehicle_arc_line(2,1),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line(3,1),[1:Num_metro_line]))||temp_value==0
        value=0;
    else
        value=1;
    end
end
