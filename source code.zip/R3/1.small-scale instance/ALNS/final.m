function [Objective,Cost,Travel_time,Fa1,Fa2,Num_bus,Bus_frequency,Bus_type,Max_route_demand]=final(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer)

global N_bus
global Fmin
global Fmax
N_bus_min=zeros(1,Num_bus_line);
N_bus_max=zeros(1,Num_bus_line);
current_N_bus=zeros(1,Num_bus_line);
current_bus_frequency=zeros(1,Num_bus_line);
for i=1:Num_bus_line
    N_bus_min(1,i)=ceil(Fmin*2*time_bus_line(1,i));
    N_bus_max(1,i)=ceil(Fmax*2*time_bus_line(1,i));
end
N_min_total=sum(N_bus_min(1,:));
N_max_total=min(N_bus,sum(N_bus_max(1,:)));
G=N_max_total-N_min_total;
Best_objective=zeros(1,G);
Best_bus_frequency=cell(1,G);
Best_bus_type=cell(1,G);
Best_N_bus=cell(1,G);
Best_cost=zeros(1,G);
Best_travel_time=zeros(1,G);
Best_fa1=zeros(1,G);
Best_fa2=zeros(1,G);
Best_route_demand_max=cell(1,G);
for g=1:N_max_total-N_min_total
    N_bus_total=N_min_total+g;
    for j=1:Num_bus_line
        if j==1
            current_N_bus(1,j)=N_bus_min(1,j)+N_bus_total-N_min_total;
        else
            current_N_bus(1,j)=N_bus_min(1,j);
        end
        current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
    end
    [utility,travel_time]=cal_utility(Num_total_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer,current_bus_frequency);
    [OD_Kpath_demand,route_demand_max]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
    current_bus_type=cal_bustype(Num_bus_line,route_demand_max,current_bus_frequency);
    [best_objective,best_cost,best_travel_time,best_fa1,best_fa2]=cal_objective(Num_bus_line,length_bus_line,current_bus_frequency,current_bus_type,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max);
    best_bus_frequency=current_bus_frequency;
    best_bus_type=current_bus_type;
    best_N_bus=current_N_bus;
    best_route_demand_max=route_demand_max;
   
    i=1;
    while i<=Num_bus_line
        if  current_N_bus(1,i)>N_bus_min(1,i)
            j=i+1;
            while j<=Num_bus_line
                current_N_bus(1,i)=current_N_bus(1,i)-1;
                current_N_bus(1,j)=current_N_bus(1,j)+1;
                if current_N_bus(1,i)<N_bus_min(1,i)%其实是多余的
                    current_N_bus(1,i)=current_N_bus(1,i)+1;
                    current_N_bus(1,j)=current_N_bus(1,j)-1;
                    i=i+1;
                else
                    if current_N_bus(1,j)>N_bus_max(1,j)
                        current_N_bus(1,i)=current_N_bus(1,i)+1;
                        current_N_bus(1,j)=current_N_bus(1,j)-1;
                        j=j+1;
                    else
                        current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                        current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                        [utility,travel_time]=cal_utility(Num_total_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer,current_bus_frequency);
                        [OD_Kpath_demand,route_demand_max]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
                        current_bus_type=cal_bustype(Num_bus_line,route_demand_max,current_bus_frequency);
                        [objective,cost,travel_time,fa1,fa2]=cal_objective(Num_bus_line,length_bus_line,current_bus_frequency,current_bus_type,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max);
                        if objective<best_objective
                            best_objective=objective;
                            best_bus_frequency=current_bus_frequency;
                            best_bus_type=current_bus_type;
                            best_N_bus=current_N_bus;
                            best_cost=cost;
                            best_travel_time=travel_time;
                            best_fa1=fa1;
                            best_fa2=fa2;
                            best_route_demand_max=route_demand_max;
                        else
                            current_N_bus(1,i)=current_N_bus(1,i)+1;
                            current_N_bus(1,j)=current_N_bus(1,j)-1;
                            current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                            current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                            j=j+1;
                        end
                    end
                end%end if
            end%while j
            if current_N_bus(1,i)>N_bus_max(1,i)
                i=i;
            else
                i=i+1;
            end
        else
            i=i+1;
        end
    end%while i
    Best_objective(1,g)=best_objective;
    Best_bus_frequency{1,g}=best_bus_frequency;
    Best_bus_type{1,g}=best_bus_type;
    Best_N_bus{1,g}=best_N_bus;
    Best_cost(1,g)=best_cost;
    Best_travel_time(1,g)=best_travel_time;
    Best_fa1(1,g)=best_fa1;
    Best_fa2(1,g)=best_fa2;
    Best_route_demand_max{1,g}=best_route_demand_max;
end%g
min_position=find(Best_objective==min(Best_objective));
if size(min_position,2)>1
min_position=min_position(1,1);
end
Objective=Best_objective(1,min_position);
Cost=Best_cost(1,min_position);
Travel_time=Best_travel_time(1,min_position);
Fa1=Best_fa1(1,min_position);
Fa2=Best_fa2(1,min_position);
Num_bus=Best_N_bus{1,min_position};
Bus_frequency=Best_bus_frequency{1,min_position};
Bus_type=Best_bus_type{1,min_position};
Max_route_demand=Best_route_demand_max{1,min_position};
 