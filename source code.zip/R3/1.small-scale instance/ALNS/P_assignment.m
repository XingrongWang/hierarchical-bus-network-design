function [OD_Kpath_demand,route_demand_max,route_demand1,route_demand2]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line)
global N_platform
global K
global theta
global OD
OD_Kpath_demand=cell(N_platform,N_platform);
for s=1:N_platform
    for e=1:N_platform
        if e~=s
            for k=1:K
                OD_Kpath_demand{s,e}(1,k)=round(exp(-theta*utility(s,e,k)/min(utility(s,e,:)))/sum(exp(-theta*utility(s,e,:)/min(utility(s,e,:))))*OD(s,e));
            end
        end
    end
end
%******************************************************************************************************
arc_demand=zeros(Num_total_node,Num_total_node);
for s=1:N_platform
    for e=1:N_platform
        if e~=s
            for k=1:K
                for i=1:size(OD_Kpath_set{s,e}{1,1+k},2)-1
                    arc_demand(OD_Kpath_set{s,e}{1,1+k}(1,i),OD_Kpath_set{s,e}{1,1+k}(1,i+1))=arc_demand(OD_Kpath_set{s,e}{1,1+k}(1,i),OD_Kpath_set{s,e}{1,1+k}(1,i+1))+OD_Kpath_demand{s,e}(1,k);
                end
            end
        end
    end
end
route_demand1=cell(1,Num_total_line);
route_demand2=cell(1,Num_total_line);
route_demand_max=zeros(1,Num_total_line);
for i=1:Num_total_line
    for j=1:size(new_total_line{1,i},2)-1
        route_demand1{1,i}(1,j)=arc_demand(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1));
        route_demand2{1,i}(1,j)=arc_demand(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j));
    end
    route_demand_temp=[route_demand1{1,i},route_demand2{1,i}];
    route_demand_max(1,i)=max(route_demand_temp);
end
