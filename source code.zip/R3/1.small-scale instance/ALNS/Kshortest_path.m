function [k_shortest_path,k_time_path,original_line_temp,inline_transfer_temp,arc_transfer_temp,Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=Kshortest_path(A,weight,s,e,Num_total_line,new_total_line,plat_line,total_line,plat_line_node)

global K
global Num_transfer_allow
global N_platform
global cofficient

k_shortest_path=cell(1,K);
k_time_path=zeros(1,K);
original_line_temp=zeros(1,K);
inline_transfer_temp=cell(1,K);
arc_transfer_temp=cell(1,K);
invehicle_arc_line_temp=cell(1,K);
invehicle_arc_temp=cell(1,K);
Num_transfer_temp=zeros(1,K);
%******************************
Kmax=5;
k_shortest_path1=cell(1,Kmax);
k_time_path1=zeros(1,Kmax);
inline_transfer_temp1=cell(1,Kmax);
arc_transfer_temp1=cell(1,Kmax);
original_line_temp1=zeros(1,Kmax);
Num_transfer_temp1=zeros(1,Kmax);
invehicle_arc_temp1=cell(1,Kmax);
invehicle_arc_line_temp1=cell(1,Kmax);
k=1;
weight_temp=weight;
for i=1:N_platform
    if i~=s&&i~=e
        for j=1:size(plat_line{1,i},2)
            temp_position=find(total_line{1,plat_line{1,i}(1,j)}(1,:)==i);
            weight_temp(i,new_total_line{1,plat_line{1,i}(1,j)}(1,temp_position))=inf;
            weight_temp(new_total_line{1,plat_line{1,i}(1,j)}(1,temp_position),i)=inf;
            for jj=j+1:size(plat_line{1,i},2)
                weight_temp(plat_line_node{1,i}(1,j),plat_line_node{1,i}(1,jj))=10000;
                weight_temp(plat_line_node{1,i}(1,jj),plat_line_node{1,i}(1,j))=10000;
            end
        end
    end
end
while k<=Kmax
    if k==1
        [k_shortest_path1{1,k},k_time_path1(1,k)]=shortest_path(A,weight_temp,s,e);
        [original_line_temp1(1,k),inline_transfer_temp1{1,k},arc_transfer_temp1{1,k},Num_transfer_temp1(1,k),invehicle_arc_temp1{1,k},invehicle_arc_line_temp1{1,k}]=calculate_path_attribute(k_shortest_path1{1,k},Num_total_line,new_total_line);
    else
        n_node=size(k_shortest_path1{1,k-1}(1,:),2);
        if mod(n_node,2)==0
            weight_temp(k_shortest_path1{1,k-1}(1,n_node/2),k_shortest_path1{1,k-1}(1,n_node/2+1))=inf;
        else
            weight_temp(k_shortest_path1{1,k-1}(1,(n_node+1)/2-1),k_shortest_path1{1,k-1}(1,(n_node+1)/2))=inf;
        end
        [k_shortest_path1{1,k},k_time_path1(1,k)]=shortest_path(A,weight_temp,s,e);
        if k_time_path1(1,k)==inf
            k_time_path1(1,k)=k_time_path1(1,1);
            k_shortest_path1{1,k}=k_shortest_path1{1,1};
            original_line_temp1(1,k)=original_line_temp1(1,1);
            inline_transfer_temp1{1,k}=inline_transfer_temp1{1,1};
            arc_transfer_temp1{1,k}=arc_transfer_temp1{1,1};
            Num_transfer_temp1(1,k)=Num_transfer_temp1(1,1);
            invehicle_arc_temp1{1,k}=invehicle_arc_temp1{1,1};
            invehicle_arc_line_temp1{1,k}=invehicle_arc_line_temp1{1,1};
        else
            [original_line_temp1(1,k),inline_transfer_temp1{1,k},arc_transfer_temp1{1,k},Num_transfer_temp1(1,k),invehicle_arc_temp1{1,k},invehicle_arc_line_temp1{1,k}]=calculate_path_attribute(k_shortest_path1{1,k},Num_total_line,new_total_line);
        end
    end
    k=k+1;
end
same_line=cell(1,Kmax);
for k=1:Kmax
    same_line{1,k}=[];
    for i=k+1:Kmax
        if isequal(k_shortest_path1{1,i},k_shortest_path1{1,k})
            same_line{1,k}=[same_line{1,k},i];
        end
    end
end
same_position=[];
for k=Kmax:-1:1
    for i=1:Kmax
        if ismember(k,same_line{1,i})
            same_position=[same_position,k];
        end
    end
end
same_position=unique(same_position);
k_time_path1(same_position)=[];
k_shortest_path1(same_position)=[];
original_line_temp1(same_position)=[];
inline_transfer_temp1(same_position)=[];
arc_transfer_temp1(same_position)=[];
Num_transfer_temp1(same_position)=[];
invehicle_arc_temp1(same_position)=[];
invehicle_arc_line_temp1(same_position)=[];

k_shortest_path_set={};
time_k_shortest_path_set=[];
position_k_shortest_path_set=[];
Num_transfer_set=[];
Kmax=size(k_shortest_path1,2);
[shortest_path_temp,time_shortest_path]=shortest_path(A,weight,s,e);
real_time=zeros(1,Kmax);
for k=1:Kmax
    for i=1:size(k_shortest_path1{1,k},2)-1
        real_time(1,k)=real_time(1,k)+weight(k_shortest_path1{1,k}(1,i),k_shortest_path1{1,k}(1,i+1));
    end
end
for k=1:Kmax
    if Num_transfer_temp1(1,k)<=Num_transfer_allow&&real_time(1,k)<=cofficient*time_shortest_path
        value=judge_transfer(Num_transfer_temp1(1,k),invehicle_arc_line_temp1{1,k},Num_total_line);
        if value==1
        position_k_shortest_path_set=[position_k_shortest_path_set,k];
        k_shortest_path_set=[k_shortest_path_set,k_shortest_path1{1,k}];
        time_k_shortest_path_set=[time_k_shortest_path_set,real_time(1,k)];
        Num_transfer_set=[Num_transfer_set,Num_transfer_temp1(1,k)];
        end
    end
end
[Num_transfer_set_new1,rank_position1]=sort(Num_transfer_set);
number_transfer0=[];
number_transfer1=[];
number_transfer2=[];
number_transfer3=[];
time_transfer0=[];
time_transfer1=[];
time_transfer2=[];
time_transfer3=[];
for i=1:size(Num_transfer_set_new1,2)
    if Num_transfer_set_new1(1,i)==0
        number_transfer0=[number_transfer0,rank_position1(1,i)];
        time_transfer0=[time_transfer0,time_k_shortest_path_set(1,rank_position1(1,i))];
    else
        if Num_transfer_set_new1(1,i)==1
            number_transfer1=[number_transfer1,rank_position1(1,i)];
            time_transfer1=[time_transfer1,time_k_shortest_path_set(1,rank_position1(1,i))];
        else
            if Num_transfer_set_new1(1,i)==2
                number_transfer2=[number_transfer2,rank_position1(1,i)];
                time_transfer2=[time_transfer2,time_k_shortest_path_set(1,rank_position1(1,i))];
            else
                if Num_transfer_set_new1(1,i)==3
                    number_transfer3=[number_transfer3,rank_position1(1,i)];
                    time_transfer3=[time_transfer3,time_k_shortest_path_set(1,rank_position1(1,i))];
                end
            end
        end
    end
end
[rank_time0,rank_time_position0]=sort(time_transfer0);
[rank_time1,rank_time_position1]=sort(time_transfer1);
[rank_time2,rank_time_position2]=sort(time_transfer2);
[rank_time3,rank_time_position3]=sort(time_transfer3);
new_number_transfer0=number_transfer0;
new_number_transfer1=number_transfer1;
new_number_transfer2=number_transfer2;
new_number_transfer3=number_transfer3;
for i=1:size(number_transfer0,2)
    new_number_transfer0(1,i)=number_transfer0(1,rank_time_position0(1,i));
end
for i=1:size(number_transfer1,2)
    new_number_transfer1(1,i)=number_transfer1(1,rank_time_position1(1,i));
end
for i=1:size(number_transfer2,2)
    new_number_transfer2(1,i)=number_transfer2(1,rank_time_position2(1,i));
end
for i=1:size(number_transfer3,2)
    new_number_transfer3(1,i)=number_transfer3(1,rank_time_position3(1,i));
end
if Num_transfer_allow==2
    new_number_transfer=[new_number_transfer0,new_number_transfer1,new_number_transfer2];
else
    if Num_transfer_allow==3
        new_number_transfer=[new_number_transfer0,new_number_transfer1,new_number_transfer2,new_number_transfer3];
    end
end
if size(new_number_transfer,2)==0
    for k=1:K
        k_shortest_path{1,k}=[];
        k_time_path(1,k)=inf;
        inline_transfer_temp{1,k}=[];
        arc_transfer_temp{1,k}=[];
        original_line_temp(1,k)=0;
        Num_transfer_temp(1,k)=0;
        invehicle_arc_temp{1,k}={};
        invehicle_arc_line_temp{1,k}=[];
    end
else
    if size(new_number_transfer,2)>=K
        for k=1:K
            k_shortest_path{1,k}=k_shortest_path_set{1,new_number_transfer(1,k)};
            k_time_path(1,k)=time_k_shortest_path_set(1,new_number_transfer(1,k));
        end
    else
        for k=1:size(new_number_transfer,2)
            k_shortest_path{1,k}=k_shortest_path_set{1,new_number_transfer(1,k)};
            k_time_path(1,k)=time_k_shortest_path_set(1,new_number_transfer(1,k));
        end
        for k=size(new_number_transfer,2)+1:K
            k_shortest_path{1,k}=k_shortest_path_set{1,new_number_transfer(1,1)};
            k_time_path(1,k)=time_k_shortest_path_set(1,new_number_transfer(1,1));
        end
    end
    for k=1:K
        [original_line_temp(1,k),inline_transfer_temp{1,k},arc_transfer_temp{1,k},Num_transfer_temp(1,k),invehicle_arc_temp{1,k},invehicle_arc_line_temp{1,k}]=calculate_path_attribute(k_shortest_path{1,k},Num_total_line,new_total_line);
    end
end

    








