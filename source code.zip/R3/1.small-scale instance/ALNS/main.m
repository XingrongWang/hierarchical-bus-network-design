clear
clc
global cost_max
cost_max=20000;
global min_avg_load
min_avg_load=0.1;
global N_platform
N_platform=24;
global K KK
K=3;
KK=3;
global Num_metro_line
Num_metro_line=2;
global Metro_line Metro_station
Metro_line=cell(1,Num_metro_line);  
Metro_line{1,1}=[1,2,8,10,22,20];
Metro_line{1,2}=[5,10,12,13,21,20,18];
Metro_station=[Metro_line{1,1},Metro_line{1,2}];
Metro_station=unique(Metro_station);
global C_metro f_metro h_metro
C_metro=500;
f_metro=6;
h_metro=10;
global Fmin Fmax
Fmin=10;
Fmax=20;
F=[Fmin:Fmax];
H=1./F*60;
global N_bus Max_bus_line Max_trunk_line Max_main_line Max_feeder_line
N_bus=80;
Max_bus_line=18;
Max_trunk_line=4; 
Max_main_line=12;
Max_feeder_line=2;
global Max_length_trunk Min_length_trunk Max_length_main Min_length_main Max_length_feeder Min_length_feeder 
Max_length_trunk=15;
Min_length_trunk=5;
Max_length_main=15;
Min_length_main=5;
Max_length_feeder=10;
Min_length_feeder=3;
global Max_arc_line
Max_arc_line=4;
global v_bus_normal v_bus_rapid v_metro dwell_time v_walk
v_bus_normal=20;%km/h
v_bus_rapid=35;%km/h
v_metro=40;%km/h
v_walk=5;%km/h
dwell_time=0.5/60;
global Num_transfer_allow
Num_transfer_allow=2;
global cofficient
cofficient=2;
global Num_bus_type
Num_bus_type=2;
global CAP_bus
CAP_bus=[60,60];
global cost_operation
cost_operation=[1.92,1.92];
global transfer_penalty
transfer_penalty=[2 2.6 2.16 2];
global VOT theta
VOT=0.54;
theta=1.8660;
global trunk_matrix main_feeder_matrix metro_matrix road_matrix
global length_trunk_matrix length_main_feeder_matrix length_metro_matrix length_road_matrix
global time_trunk_matrix time_main_feeder_matrix time_metro_matrix
global OD
OD=[0	400	10	30	50	80	50	500	50	400	50	20	90	50	50	100	40	50	30	500	300	500	100	50
100	0	60	10	10	0	30	150	30	400	70	80	100	50	50	10	30	80	80	700	300	600	100	70
10	10	0	0	0	30	10	20	10	30	0	20	30	10	20	10	10	10	300	200	200	60	10	40
10	20	0	0	10	0	40	20	0	20	0	20	90	30	30	30	50	10	20	100	50	80	200	30
20	10	10	0	0	10	20	10	0	100	20	400	800	30	20	20	20	100	10	600	800	220	50	80
30	0	30	10	0	0	10	0	10	10	40	50	80	50	20	0	20	10	30	80	150	80	30	10
80	20	10	40	20	10	0	10	20	20	80	60	300	30	10	0	20	0	40	50	60	80	20	10
500	300	20	20	20	0	0	0	10	200	50	100	250	40	20	0	20	30	30	500	300	600	100	100
50	20	10	0	0	10	20	10	0	20	10	30	150	20	40	0	20	20	40	60	30	70	30	20
400	400	80	20	400	80	60	200	0	0	10	300	800	30	10	10	0	100	50	600	600	400	180	100
50	20	30	0	10	40	50	50	0	10	0	10	60	0	30	30	30	60	40	100	40	40	30	40
20	100	20	10	600	20	50	100	30	200	0	0	500	0	20	30	60	200	100	800	600	250	70	50
80	100	50	60	600	150	100	100	60	500	30	400	0	60	70	60	50	700	80	500	300	130	10	10
50	150	10	20	10	100	20	40	20	20	0	10	30	0	0	30	20	10	30	50	40	50	70	40
80	30	10	20	20	20	50	30	20	10	10	70	70	0	0	20	10	20	0	30	20	10	10	40
50	20	30	20	10	0	0	0	10	10	20	70	100	20	30	0	0	0	20	60	60	50	50	30
70	30	50	50	20	10	30	20	30	10	20	20	50	30	0	0	0	20	0	50	60	30	60	30
50	30	80	80	50	10	0	10	20	20	20	120	600	100	80	10	20	0	30	400	600	100	150	100
30	10	0	20	10	20	40	70	40	180	40	30	30	30	0	10	0	30	0	120	40	120	30	10
600	500	150	200	500	200	50	500	60	500	60	700	600	50	110	50	160	300	120	0	120	300	70	40
80	50	0	20	500	10	20	80	30	400	40	300	200	40	80	60	60	600	40	200	0	180	70	50
500	500	180	140	120	120	50	400	90	300	110	70	130	120	260	120	170	300	120	100	180	0	10	10
30	10	10	50	10	10	20	30	50	50	10	70	80	0	10	50	60	10	30	70	70	10	0	0
200	200	0	300	0	10	100	20	20	80	60	50	70	40	40	30	30	100	10	40	50	10	0	0
];
OD=round(OD*0.5);
road_matrix=[0	1	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
1	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
1	0	0	1	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0
0	0	1	0	1	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	1	0	1	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	1	0	0	1	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0
0	0	0	0	0	1	1	0	1	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0
0	0	0	0	1	0	0	1	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	1	0	1	0	0	0	1	1	1	0	0	0	0	0	0	0
0	0	0	1	0	0	0	0	0	1	0	1	0	1	0	0	0	0	0	0	0	0	0	0
0	0	1	0	0	0	0	0	0	0	1	0	1	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	1
0	0	0	0	0	0	0	0	0	0	1	0	0	0	1	0	0	0	0	0	0	0	1	0
0	0	0	0	0	0	0	0	0	1	0	0	0	1	0	0	0	0	1	0	0	1	0	0
0	0	0	0	0	0	0	1	0	1	0	0	0	0	0	0	1	1	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	1	0	0	1	0	0	0	0	0
0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	1	0	0	0	1	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	1	0	1	0	0	1	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	1	1	0	1	1	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	1	0	1	0	1
0	0	0	0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0	1	1	0	1	0
0	0	0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	1	0	1
0	0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	1	0	1	0
];
metro_matrix=[0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
1	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	1	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	1	0	0	1	0	0	0	1	0	0	0	0	0	0	0	0	0	1	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	1	0	0	1	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	1	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	1	0	0	1	1	0	0
0	0	0	0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	1	0	0	0	0
0	0	0	0	0	0	0	0	0	1	0	0	0	0	0	0	0	0	0	1	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0
];
length_road_matrix=[10000	2.3	0.7	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
2.3	10000	10000	10000	10000	0.7	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
0.7	10000	10000	0.7	10000	10000	10000	10000	10000	10000	10000	1	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	0.7	10000	0.6	10000	10000	10000	10000	10000	1	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	0.6	10000	1	10000	10000	0.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	0.7	10000	10000	1	10000	10000	0.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	0.7	10000	10000	10000	10000	10000	10000	10000	10000	10000	0.5	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	0.5	0.7	10000	1	10000	10000	10000	10000	10000	10000	0.5	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	0.5	10000	10000	1	10000	0.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	0.5	10000	0.6	10000	10000	10000	1	1	1.1	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	1	10000	10000	10000	10000	10000	0.6	10000	0.7	10000	1	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	1	10000	10000	10000	10000	10000	10000	10000	0.7	10000	2.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	2.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	0.7
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	1	10000	10000	10000	0.6	10000	10000	10000	10000	10000	10000	10000	0.6	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	1	10000	10000	10000	0.6	10000	10000	10000	10000	1	10000	10000	0.6	10000	10000
10000	10000	10000	10000	10000	10000	10000	0.5	10000	1	10000	10000	10000	10000	10000	10000	0.5	0.7	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	1.1	10000	10000	10000	10000	10000	0.5	10000	10000	0.5	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	0.5	10000	10000	10000	10000	10000	10000	10000	10000	0.7	10000	10000	10000	2.6	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	1	10000	0.5	10000	10000	1.5	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	2.6	1.5	10000	1	1.2	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	1	10000	0.9	10000	0.6
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	0.6	10000	10000	10000	10000	1.2	0.9	10000	0.6	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	0.6	10000	10000	10000	10000	10000	10000	10000	0.6	10000	0.9
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	0.7	10000	10000	10000	10000	10000	10000	10000	0.6	10000	0.9	10000
];

length_metro_matrix=[10000	2.3	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
2.3	10000	10000	10000	10000	10000	10000	1.2	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	1	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	1.2	10000	10000	10000	10000	10000	10000	10000	1.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	1	10000	10000	1.5	10000	10000	10000	1.3	10000	10000	10000	10000	10000	10000	10000	10000	10000	1.6	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	1.3	10000	10000	2.5	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	2.5	10000	10000	10000	10000	10000	10000	10000	10000	1.3	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	2.6	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	2.6	10000	10000	1	1.2	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	1.3	10000	10000	10000	10000	10000	10000	1	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	1.6	10000	10000	10000	10000	10000	10000	10000	10000	10000	1.2	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000	10000
];
[trunk_matrix,length_trunk_matrix]=generate_trunk;
[main_feeder_matrix,length_main_feeder_matrix]=generate_main_feeder;
time_trunk_matrix=length_trunk_matrix/v_bus_rapid;
time_main_feeder_matrix=length_main_feeder_matrix/v_bus_normal;
time_metro_matrix=length_metro_matrix/v_metro;
[trunk_line,main_line,feeder_line,Num_bus_line]=initial_network;
[Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
[OD_Kpath_set,original_line,inline_transfer,arc_transfer,Num_transfer,invehicle_arc,invehicle_arc_line]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);
[Objective,Cost,Total_travel_time,Total_wait_time,Total_invehicle_time,Total_transfer_time,Total_transfer_time_walk,Total_transfer_time_penalty,Fa1,Fa2,Fa3,Fa4,Num_bus,Bus_frequency,Bus_type,Bus_flow]=cal_objective_frequency_type(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,arc_transfer,invehicle_arc,invehicle_arc_line,Num_transfer);          
global currentbest_OD_Kpath_set currentbest_original_line currentbest_inline_transfer currentbest_arc_transfer currentbest_Num_transfer currentbest_invehicle_arc currentbest_invehicle_arc_line
currentbest_bus_line={trunk_line,main_line,feeder_line};
currentbest_num_bus_line=Num_bus_line;
currentbest_bus_frequency=Bus_frequency;
currentbest_bus_type=Bus_type;
currentbest_objective=Objective;
currentbest_cost=Cost;
currentbest_total_travel_time=Total_travel_time;
currentbest_total_wait_time=Total_wait_time;
currentbest_total_invehicle_time=Total_invehicle_time;
currentbest_total_transfer_time=Total_transfer_time;
currentbest_total_transfer_time_walk=Total_transfer_time_walk;
currentbest_total_transfer_time_penalty=Total_transfer_time_penalty;
currentbest_fa1=Fa1;
currentbest_fa2=Fa2;
currentbest_fa3=Fa3;
currentbest_fa4=Fa4;
currentbest_bus_flow=Bus_flow;
currentbest_Num_bus=Num_bus;
currentbest_plat_line_bus=plat_line_bus;
currentbest_OD_Kpath_set=OD_Kpath_set;
currentbest_original_line=original_line;
currentbest_inline_transfer=inline_transfer;
currentbest_arc_transfer=arc_transfer;
currentbest_Num_transfer=Num_transfer;
currentbest_invehicle_arc=invehicle_arc;
currentbest_invehicle_arc_line=invehicle_arc_line;
best_bus_line={trunk_line,main_line,feeder_line};
best_num_bus_line=Num_bus_line;
best_bus_frequency=Bus_frequency;
best_bus_type=Bus_type;
best_objective=Objective;
best_cost=Cost;
best_total_travel_time=Total_travel_time;
best_total_wait_time=Total_wait_time;
best_total_invehicle_time=Total_invehicle_time;
best_total_transfer_time=Total_transfer_time;
best_total_transfer_time_walk=Total_transfer_time_walk;
best_total_transfer_time_penalty=Total_transfer_time_penalty;
best_fa1=Fa1;
best_fa2=Fa2;
best_fa3=Fa3;
best_fa4=Fa4;
best_bus_flow=Bus_flow;
best_Num_bus=Num_bus;
best_plat_line_bus=plat_line_bus;
%****************************************
G=15;
iteriation=60;
Num_operator=9;
T=zeros(1,G);
p=zeros(G,Num_operator);
score=zeros(G,Num_operator);
weight=zeros(G,Num_operator);
N_total=zeros(G,Num_operator);
T_initial=26000;
sita1=30;
sita2=10;
sita3=5;
fai=0.2;
alfa=0.2;
value=0;
y=zeros(G,iteriation);
y1=zeros(1,G*iteriation);
n=zeros(1,G*iteriation);
for g=1:G
    if g==1
        T(1,g)=T_initial;
        weight(g,:)=1;
    else
        T(1,g)=fai*T(1,g-1);
        for k=1:Num_operator
            if N_total(g-1,k)==0
                weight(g,k)=weight(g-1,k);
            else
                weight(g,k)=(1-alfa)*weight(g-1,k)+alfa*score(g-1,k)/N_total(g-1,k);
            end
        end
    end
    score(g,:)=0;
    for k=1:Num_operator
        p(g,k)=weight(g,k)/sum(weight(g,:));
        p_temp=cumsum(p(g,:));
    end
    for i=1:iteriation
        value_temp=rand();
        for k=1:Num_operator
            if k==1
                if value_temp<=p_temp(1,k)
                    operator=k;
                end
            else
                if value_temp<=p_temp(1,k)&&value_temp>p_temp(1,k-1)
                    operator=k;
                end
            end
        end
        tic
        if operator==1
            [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator1(currentbest_bus_line);
        else
            if operator==2
                [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator2(currentbest_bus_line);
            else
                if operator==3
                    [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator3(currentbest_bus_line);
                else
                    if operator==4
                        [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator4(currentbest_bus_line);
                    else
                        if operator==5
                            [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator5(currentbest_bus_line);
                        else
                            if operator==6
                                [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator6(currentbest_bus_line);
                            else
                                if operator==7
                                    [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator7(currentbest_bus_line);
                                else
                                    if operator==8
                                        [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator8(currentbest_bus_line);
                                    else
                                        if operator==9
                                            [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator9(currentbest_bus_line);
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        N_total(g,operator)=N_total(g,operator)+1;
        if value_update==1
            [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(new_trunk_line,new_main_line,new_feeder_line);
            [local_objective,local_cost,local_total_travel_time,local_total_wait_time,local_total_invehicle_time,local_total_transfer_time,local_total_transfer_time_walk,local_total_transfer_time_penalty,local_fa1,local_fa2,local_fa3,local_fa4,local_Num_bus,local_bus_frequency,local_bus_type,local_bus_flow]=cal_objective_frequency_type(Num_total_line,new_num_bus_line,Num_total_node,new_total_line,new_OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,new_original_line,new_inline_transfer,new_arc_transfer,new_invehicle_arc,new_invehicle_arc_line,new_Num_transfer);
        else
            local_objective=currentbest_objective;
            local_cost=currentbest_cost;
            local_total_travel_time=currentbest_total_travel_time;
            local_total_wait_time=currentbest_total_wait_time;
            local_total_invehicle_time=currentbest_total_invehicle_time;
            local_total_transfer_time=currentbest_total_transfer_time;
            local_total_transfer_time_walk=currentbest_total_transfer_time_walk;
            local_total_transfer_time_penalty=currentbest_total_transfer_time_penalty;
            local_fa1=currentbest_fa1;
            local_fa2=currentbest_fa2;
            local_fa3=currentbest_fa3;
            local_fa4=currentbest_fa4;
            local_Num_bus=currentbest_Num_bus;
            local_bus_frequency=currentbest_bus_frequency;
            local_bus_type=currentbest_bus_type;
            local_bus_flow=currentbest_bus_flow;
        end
        if local_objective<currentbest_objective
            currentbest_bus_line={new_trunk_line,new_main_line,new_feeder_line};
            currentbest_num_bus_line=new_num_bus_line;
            currentbest_bus_frequency=local_bus_frequency;
            currentbest_bus_type=local_bus_type;
            currentbest_cost=local_cost;
            currentbest_total_travel_time=local_total_travel_time;
            currentbest_total_wait_time=local_total_wait_time;
            currentbest_total_invehicle_time=local_total_invehicle_time;
            currentbest_total_transfer_time=local_total_transfer_time;
            currentbest_total_transfer_time_walk=local_total_transfer_time_walk;
            currentbest_total_transfer_time_penalty=local_total_transfer_time_penalty;
            currentbest_fa1=local_fa1;
            currentbest_fa2=local_fa2;
            currentbest_fa3=local_fa3;
            currentbest_fa4=local_fa4;
            currentbest_bus_flow=local_bus_flow;
            currentbest_Num_bus=local_Num_bus;
            currentbest_objective=local_objective;
            currentbest_plat_line_bus=plat_line_bus;
            currentbest_OD_Kpath_set=new_OD_Kpath_set;
            currentbest_original_line=new_original_line;
            currentbest_inline_transfer=new_inline_transfer;
            currentbest_arc_transfer=new_arc_transfer;
            currentbest_Num_transfer=new_Num_transfer;
            currentbest_invehicle_arc=new_invehicle_arc;
            currentbest_invehicle_arc_line=new_invehicle_arc_line;
            if local_objective<best_objective
                best_bus_line={new_trunk_line,new_main_line,new_feeder_line};
                best_num_bus_line=new_num_bus_line;
                best_bus_frequency=local_bus_frequency;
                best_bus_type=local_bus_type;
                best_cost=local_cost;
                best_total_travel_time=local_total_travel_time;
                best_total_wait_time=local_total_wait_time;
                best_total_invehicle_time=local_total_invehicle_time;
                best_total_transfer_time=local_total_transfer_time;
                currentbest_total_transfer_time_walk=local_total_transfer_time_walk;
                currentbest_total_transfer_time_penalty=local_total_transfer_time_penalty;
                best_fa1=local_fa1;
                best_fa2=local_fa2;
                best_fa3=local_fa3;
                best_fa4=local_fa4;
                best_bus_flow=local_bus_flow;
                best_Num_bus=local_Num_bus;
                best_objective=local_objective;
                best_plat_line_bus=plat_line_bus;
                score(g,operator)=score(g,operator)+sita1;
            else
                score(g,operator)=score(g,operator)+sita2;
            end
        else
            delta=local_objective-currentbest_objective;
            p_accept=exp(-delta/T(1,g));
            if p_accept>rand
                value=1;
                currentbest_bus_line={new_trunk_line,new_main_line,new_feeder_line};
                currentbest_num_bus_line=new_num_bus_line;
                currentbest_bus_frequency=local_bus_frequency;
                currentbest_bus_type=local_bus_type;
                currentbest_cost=local_cost;
                currentbest_total_travel_time=local_total_travel_time;
                currentbest_total_wait_time=local_total_wait_time;
                currentbest_total_invehicle_time=local_total_invehicle_time;
                currentbest_total_transfer_time=local_total_transfer_time;
                currentbest_total_transfer_time_walk=local_total_transfer_time_walk;
                currentbest_total_transfer_time_penalty=local_total_transfer_time_penalty;
                currentbest_fa1=local_fa1;
                currentbest_fa2=local_fa2;
                currentbest_fa3=local_fa3;
                currentbest_fa4=local_fa4;
                currentbest_bus_flow=local_bus_flow;
                currentbest_Num_bus=local_Num_bus;
                currentbest_objective=local_objective;
                currentbest_plat_line_bus=plat_line_bus;
                currentbest_OD_Kpath_set=new_OD_Kpath_set;
                currentbest_original_line=new_original_line;
                currentbest_inline_transfer=new_inline_transfer;
                currentbest_arc_transfer=new_arc_transfer;
                currentbest_Num_transfer=new_Num_transfer;
                currentbest_invehicle_arc=new_invehicle_arc;
                currentbest_invehicle_arc_line=new_invehicle_arc_line;
                score(g,operator)=score(g,operator)+sita3;
            end
        end
        toc
        y(g,i)=best_objective;
    end
end%g
for g=1:G
    for i=1:iteriation
        n(1,(g-1)*iteriation+i)=(g-1)*iteriation+i;
        y1(1,(g-1)*iteriation+i)=y(g,i);
    end
end
plot(n,y1)
