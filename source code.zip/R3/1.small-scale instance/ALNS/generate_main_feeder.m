function [main_feeder_matrix,length_main_feeder_matrix]=generate_main_feeder
global N_platform
global road_matrix
global length_road_matrix
max_limit_trunk=1;
min_limit_trunk=0;
main_feeder_matrix=zeros(N_platform,N_platform);
length_main_feeder_matrix=zeros(N_platform,N_platform);
for i=1:N_platform
    for j=1:N_platform
        if j~=i
            [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
            if length_path_temp<=max_limit_trunk&&length_path_temp>=min_limit_trunk
                main_feeder_matrix(i,j)=1;
                length_main_feeder_matrix(i,j)=length_path_temp;
            end
        end
    end
end
for i=1:N_platform
    for j=1:N_platform
        if main_feeder_matrix(i,j)==0
            length_main_feeder_matrix(i,j)=10000;
        end
    end
end
