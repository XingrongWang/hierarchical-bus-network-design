function [original_line_temp,inline_transfer_temp,arc_transfer_temp,Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=calculate_path_attribute(path,Num_total_line,new_total_line) 
arc_transfer_temp=[];
inline_transfer_temp=[];
for n=1:Num_total_line
    if ismember(path(1,2),new_total_line{1,n}(1,:))
        original_line_temp=n;
        break
    else
        original_line_temp=0;
    end
end
for i=2:size(path,2)-2
    location_line_i=0;
    location_line_i_nextnode=0;
    for n=1:Num_total_line
        if ismember(path(1,i),new_total_line{1,n}(1,:))
            location_line_i=n;
        end
        if ismember(path(1,i+1),new_total_line{1,n}(1,:))
            location_line_i_nextnode=n;
        end
    end
    if location_line_i==location_line_i_nextnode
        continue
    else
        arc_transfer_temp=[arc_transfer_temp;path(1,i), path(1,i+1)];
        if location_line_i_nextnode~=0
            inline_transfer_temp=[inline_transfer_temp;location_line_i_nextnode];
        else
            inline_transfer_temp=[inline_transfer_temp;0];
        end
    end
end
Num_transfer_temp=size(inline_transfer_temp,1);
invehicle_arc_temp=cell(1,Num_transfer_temp+1);
invehicle_arc_line_temp=zeros(Num_transfer_temp+1,1);
if Num_transfer_temp==0
    invehicle_arc_temp{1,1}=path(1,2:size(path,2)-1);
else
    if Num_transfer_temp==1
        invehicle_arc_temp{1,1}=path(1,2:find(path==arc_transfer_temp(1,1)));
        invehicle_arc_temp{1,2}=path(1,find(path==arc_transfer_temp(1,2)):size(path,2)-1);
    else
        for i=1:Num_transfer_temp+1
            if i==1
            invehicle_arc_temp{1,i}=path(1,2:find(path==arc_transfer_temp(i,1)));
            else
                if i==Num_transfer_temp+1
                 invehicle_arc_temp{1,i}=path(1,find(path==arc_transfer_temp(i-1,2)):size(path,2)-1);
                else
                  invehicle_arc_temp{1,i}=path(1,find(path==arc_transfer_temp(i-1,2)):find(path==arc_transfer_temp(i,1)));
                end
            end
        end
    end
end  
invehicle_arc_line_temp=[original_line_temp;inline_transfer_temp];

