function [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line)
global Metro_line
global N_platform
global Num_metro_line
global length_trunk_matrix
global length_main_feeder_matrix
global length_metro_matrix
global time_trunk_matrix
global time_main_feeder_matrix
global time_metro_matrix
global v_walk
Num_trunk_line=size(trunk_line,2);
Num_main_line=size(main_line,2);
Num_feeder_line=size(feeder_line,2);
Num_bus_line=Num_trunk_line+Num_main_line+Num_feeder_line;
Num_total_line=Num_bus_line+Num_metro_line;
bus_line=[trunk_line,main_line,feeder_line];%线路经过的站点
length_bus_line=zeros(1,Num_bus_line);
time_bus_line=zeros(1,Num_bus_line);
total_line=[Metro_line,bus_line];

length_bus_line=zeros(1,Num_bus_line);
time_bus_line=zeros(1,Num_bus_line);
for i=1:Num_trunk_line
    for j=1:size(bus_line{1,i},2)-1
        length_bus_line(1,i)=length_bus_line(1,i)+length_trunk_matrix(bus_line{1,i}(1,j),bus_line{1,i}(1,j+1));
        time_bus_line(1,i)=time_bus_line(1,i)+time_trunk_matrix(bus_line{1,i}(1,j),bus_line{1,i}(1,j+1));
    end
end
for i=Num_trunk_line+1:Num_bus_line
    for j=1:size(bus_line{1,i},2)-1
        length_bus_line(1,i)=length_bus_line(1,i)+length_main_feeder_matrix(bus_line{1,i}(1,j),bus_line{1,i}(1,j+1));
        time_bus_line(1,i)=time_bus_line(1,i)+time_main_feeder_matrix(bus_line{1,i}(1,j),bus_line{1,i}(1,j+1));
    end
end

Num_total_node=N_platform;
new_total_line=cell(1,Num_total_line);
for i=1:Num_total_line
    Num_total_node=Num_total_node+size(total_line{1,i},2);
end
for i=1:Num_total_line
    if i==1
        for j=1:size(total_line{1,i},2)
            new_total_line{1,i}(1,j)=N_platform+j;
        end
    else
        for j=1:size(total_line{1,i},2)
            new_total_line{1,i}(1,j)=new_total_line{1,i-1}(1,size(new_total_line{1,i-1},2))+j;
        end
    end
end
plat_line=cell(1,N_platform);
plat_line_bus=cell(1,N_platform);
for i=1:N_platform
    for j=1:Num_total_line
        if ismember(i,total_line{1,j})
            plat_line{1,i}=[plat_line{1,i},j];
        end
    end
end
for i=1:N_platform
    for j=1:size(plat_line{1,i},2)
        if ismember(plat_line{1,i}(1,j),[Num_metro_line+1:Num_total_line])
        plat_line_bus{1,i}=[plat_line_bus{1,i},plat_line{1,i}(1,j)];
        end
    end
end
new_bimodal_network=zeros(Num_total_node,Num_total_node);
plat_line_node=cell(1,N_platform);
for i=1:N_platform
    if size(plat_line{1,i},2)>0
        for j=1:size(plat_line{1,i},2)
            temp_position=find(total_line{1,plat_line{1,i}(1,j)}(1,:)==i);
            new_bimodal_network(i,new_total_line{1,plat_line{1,i}(1,j)}(1,temp_position))=1;
            plat_line_node{1,i}(1,j)=new_total_line{1,plat_line{1,i}(1,j)}(1,temp_position);
        end
        for k=1:size(plat_line_node{1,i},2)-1
            for g=k+1:size(plat_line_node{1,i},2)
                new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=1;
            end
        end
    end
end
for i=1:Num_total_line
    for j=1:size(new_total_line{1,i},2)-1
       new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=1;
    end
end
for i=1:Num_total_node
    for j=1:Num_total_node
        if new_bimodal_network(i,j)==1||new_bimodal_network(j,i)==1
           new_bimodal_network(i,j)=1; 
           new_bimodal_network(j,i)=1;
        end
    end
end
Time_new_bimodal_network=zeros(Num_total_node,Num_total_node);
Time_new_bimodal_network(:,:)=inf;
Length_new_bimodal_network=zeros(Num_total_node,Num_total_node);
Length_new_bimodal_network(:,:)=inf;
for i=1:Num_metro_line
    for j=1:size(Metro_line{1,i},2)-1
      Time_new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=time_metro_matrix(Metro_line{1,i}(1,j),Metro_line{1,i}(1,j+1));
      Time_new_bimodal_network(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j))=time_metro_matrix(Metro_line{1,i}(1,j),Metro_line{1,i}(1,j+1));
      Length_new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=length_metro_matrix(Metro_line{1,i}(1,j),Metro_line{1,i}(1,j+1));
      Length_new_bimodal_network(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j))=length_metro_matrix(Metro_line{1,i}(1,j),Metro_line{1,i}(1,j+1));
    end
end
for i=Num_metro_line+1:Num_metro_line+Num_trunk_line
    for j=1:size(total_line{1,i},2)-1   
    Time_new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=time_trunk_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    Time_new_bimodal_network(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j))=time_trunk_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    Length_new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=length_trunk_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    Length_new_bimodal_network(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j))=length_trunk_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    end
end
for i=Num_metro_line+Num_trunk_line+1:Num_total_line
    for j=1:size(total_line{1,i},2)-1   
    Time_new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=time_main_feeder_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    Time_new_bimodal_network(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j))=time_main_feeder_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    Length_new_bimodal_network(new_total_line{1,i}(1,j),new_total_line{1,i}(1,j+1))=length_main_feeder_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    Length_new_bimodal_network(new_total_line{1,i}(1,j+1),new_total_line{1,i}(1,j))=length_main_feeder_matrix(total_line{1,i}(1,j),total_line{1,i}(1,j+1));
    end
end

for i=1:N_platform
    for j=1:size(plat_line{1,i},2)
    temp_position=find(total_line{1,plat_line{1,i}(1,j)}(1,:)==i);
    Time_new_bimodal_network(i,new_total_line{1,plat_line{1,i}(1,j)}(1,temp_position))=0;
    Time_new_bimodal_network(new_total_line{1,plat_line{1,i}(1,j)}(1,temp_position),i)=0;
    end  
end
for i=1:N_platform
    if size(plat_line{1,i},2)>0
        for k=1:size(plat_line_node{1,i},2)-1
            for g=k+1:size(plat_line_node{1,i},2)
                if ismember(plat_line{1,i}(1,k),[1:Num_metro_line])&&ismember(plat_line{1,i}(1,g),[1:Num_metro_line])
                    Length_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=0.1;
                    Time_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=Length_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))/v_walk;
                    Length_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))=0.1;
                    Time_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))=Length_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))/v_walk;
                else
                    if (ismember(plat_line{1,i}(1,k),[1:Num_metro_line])&&ismember(plat_line{1,i}(1,g),[Num_metro_line+1:Num_total_line]))||(ismember(plat_line{1,i}(1,k),[Num_metro_line+1:Num_total_line])&&ismember(plat_line{1,i}(1,g),[1:Num_metro_line]))
                        Length_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=0.2;
                        Time_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=Length_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))/v_walk;
                        Length_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))=0.2;
                        Time_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))=Length_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))/v_walk;
                    else
                        if ismember(plat_line{1,i}(1,k),[Num_metro_line+1:Num_total_line])&&ismember(plat_line{1,i}(1,g),[Num_metro_line+1:Num_total_line])
                            Length_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=0;
                            Time_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))=Length_new_bimodal_network(plat_line_node{1,i}(1,k),plat_line_node{1,i}(1,g))/v_walk;
                            Length_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))=0;
                            Time_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))=Length_new_bimodal_network(plat_line_node{1,i}(1,g),plat_line_node{1,i}(1,k))/v_walk;
                        end
                    end
                end
            end
        end
    end
end






