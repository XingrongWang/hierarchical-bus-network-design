function [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_OD_Kpath_set,new_original_line,new_inline_transfer,new_arc_transfer,new_Num_transfer,new_invehicle_arc,new_invehicle_arc_line]=operator3(currentbest_bus_line)
global trunk_matrix
global length_trunk_matrix
global main_feeder_matrix
global length_main_feeder_matrix
global N_platform
global KK
global currentbest_OD_Kpath_set currentbest_original_line currentbest_inline_transfer currentbest_arc_transfer currentbest_Num_transfer currentbest_invehicle_arc currentbest_invehicle_arc_line
value_update=0;
trunk_line=currentbest_bus_line{1,1};
main_line=currentbest_bus_line{1,2};
feeder_line=currentbest_bus_line{1,3};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
extend_line=[];
if num_trunk_line>0
    extend_line=[extend_line,1];
end
if num_main_line>0
    extend_line=[extend_line,2];
end
if num_feeder_line>0
    extend_line=[extend_line,3];
end
if size(extend_line,2)==0
    new_trunk_line=trunk_line;
    new_main_line=main_line;
    new_feeder_line=feeder_line;
    new_OD_Kpath_set=currentbest_OD_Kpath_set;
    new_original_line=currentbest_original_line;
    new_inline_transfer=currentbest_inline_transfer;
    new_arc_transfer=currentbest_arc_transfer;
    new_Num_transfer=currentbest_Num_transfer;
    new_invehicle_arc=currentbest_invehicle_arc;
    new_invehicle_arc_line=currentbest_invehicle_arc_line;
    value_update=0;  
else
    extend_position=ceil(rand*size(extend_line,2));
    extend_kind=extend_line(1,extend_position);
    if extend_kind==1
        n1=ceil(rand*num_trunk_line);
        n2=round(rand);
        if n2==0
            position=1;
        else
            position=size(trunk_line{1,n1},2);
        end
        s=trunk_line{1,n1}(1,position);
        inter_node=[];
        for g=1:size(trunk_line{1,n1},2)-1
            g_next_node=find(main_feeder_matrix(trunk_line{1,n1}(1,g),:)==1);
            g_next_former_node=find(main_feeder_matrix(:,trunk_line{1,n1}(1,g+1))==1)';
            inter_node=[inter_node,intersect(g_next_node,g_next_former_node)];
        end
        actual_route=[trunk_line{1,n1},inter_node];
        actual_route_temp=unique(actual_route);
        rest=setdiff([1:N_platform],actual_route_temp,'stable');
        rest_temp=randperm(size(rest,2));
        for i=1:size(rest,2)
            e=rest(1,rest_temp(1,i));
            [add_path_temp,length_path_temp]=Kshortest_line(trunk_matrix,length_trunk_matrix,s,e);
            for k=1:KK
                if n2==0
                    add_path_temp{1,k}=fliplr(add_path_temp{1,k});
                    bus_line_temp=[add_path_temp{1,k}(1,1:size(add_path_temp{1,k},2)-1),trunk_line{1,n1}];
                else
                    bus_line_temp=[trunk_line{1,n1},add_path_temp{1,k}(1,2:size(add_path_temp{1,k},2))];
                end
                length_bus_line_temp=0;
                for j=1:size(bus_line_temp,2)-1
                    length_bus_line_temp=length_bus_line_temp+length_trunk_matrix(bus_line_temp(1,j),bus_line_temp(1,j+1));
                end
                value2=judge2(length_bus_line_temp,extend_kind);
                value4=judge_trunk(bus_line_temp);
                if value2==1&&value4==1
                    break
                end
            end
            if value2==1&&value4==1
                break
            end
        end
        if value2==0||value4==0
            bus_line_temp=trunk_line{1,n1};
        end
    else
        if extend_kind==2
            n1=ceil(rand*num_main_line);
            n2=round(rand);
            if n2==0
                position=1;
            else
                position=size(main_line{1,n1},2);
            end
            s=main_line{1,n1}(1,position);
            rest=setdiff([1:N_platform],main_line{1,n1},'stable');
            rest_temp=randperm(size(rest,2));
            for i=1:size(rest,2)
                e=rest(1,rest_temp(1,i));
                [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
                for k=1:KK
                    if n2==0
                        add_path_temp{1,k}=fliplr(add_path_temp{1,k});
                        bus_line_temp=[add_path_temp{1,k}(1,1:size(add_path_temp{1,k},2)-1),main_line{1,n1}];
                    else
                        bus_line_temp=[main_line{1,n1},add_path_temp{1,k}(1,2:size(add_path_temp{1,k},2))];
                    end
                    length_bus_line_temp=0;
                    for j=1:size(bus_line_temp,2)-1
                        length_bus_line_temp=length_bus_line_temp+length_main_feeder_matrix(bus_line_temp(1,j),bus_line_temp(1,j+1));
                    end
                    value2=judge2(length_bus_line_temp,extend_kind);
                    value4=judge_main_feeder(bus_line_temp);
                    if value2==1&&value4==1
                        break
                    end
                end
                if value2==1&&value4==1
                    break
                end
            end
            if value2==0||value4==0
                bus_line_temp=main_line{1,n1};
            end
        else
            if extend_kind==3
                n1=ceil(rand*num_feeder_line);
                position=size(feeder_line{1,n1},2);
                s=feeder_line{1,n1}(1,position);
                rest=setdiff([1:N_platform],feeder_line{1,n1},'stable');
                rest_temp=randperm(size(rest,2));
                for i=1:size(rest,2)
                    e=rest(1,rest_temp(1,i));
                    [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
                    for k=1:KK
                        bus_line_temp=[feeder_line{1,n1},add_path_temp{1,k}(1,2:size(add_path_temp{1,k},2))];
                        length_bus_line_temp=0;
                        for j=1:size(bus_line_temp,2)-1
                            length_bus_line_temp=length_bus_line_temp+length_main_feeder_matrix(bus_line_temp(1,j),bus_line_temp(1,j+1));
                        end
                        value2=judge2(length_path_temp(1,k),extend_kind);
                        value8=judge_main_feeder(add_path_temp{1,k});
                        if value2==1&&value8==1
                            bus_line_temp=add_path_temp{1,k};
                            break
                        end
                    end
                    if value2==1&&value8==1
                        break
                    end
                end
                if value2==0||value8==0
                    bus_line_temp=feeder_line{1,n1};
                end
            end
        end
    end
    if extend_kind==1
        trunk_line{1,n1}=bus_line_temp;
    else
        if extend_kind==2
            main_line{1,n1}=bus_line_temp;
        else
            if extend_kind==3
                feeder_line{1,n1}=bus_line_temp;
            end
        end
    end
    currentbest_bus_line_temp=currentbest_bus_line;
    currentbest_bus_line_temp{1,extend_kind}={currentbest_bus_line{1,extend_kind}{1,1:n1-1},currentbest_bus_line{1,extend_kind}{1,n1+1:size(currentbest_bus_line{1,extend_kind},2)}};
    value3=judge3(bus_line_temp,currentbest_bus_line_temp,extend_kind);
    [value5,plat_line_bus]=judge5(trunk_line,main_line,feeder_line);
    if value3==1&&value5==1
        [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
        [OD_Kpath_set_temp,original_line_temp,inline_transfer_temp,arc_transfer_temp,Num_transfer_temp,invehicle_arc_temp,invehicle_arc_line_temp]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);
        value_temp1=ones(N_platform,N_platform);
        for s=1:N_platform
            for e=s+1:N_platform
                if ismember(inf,OD_Kpath_set_temp{s,e}{1,1})
                    value_temp1(s,e)=0;
                end
            end
        end
        if ismember(0,value_temp1)
            value6=0;
        else
            value6=1;
        end
        if value6==1
            new_trunk_line=trunk_line;
            new_main_line=main_line;
            new_feeder_line=feeder_line;
            new_OD_Kpath_set=OD_Kpath_set_temp;
            new_original_line=original_line_temp;
            new_inline_transfer=inline_transfer_temp;
            new_arc_transfer=arc_transfer_temp;
            new_Num_transfer=Num_transfer_temp;
            new_invehicle_arc=invehicle_arc_temp;
            new_invehicle_arc_line=invehicle_arc_line_temp;
            value_update=1;
        else
            new_trunk_line=currentbest_bus_line{1,1};
            new_main_line=currentbest_bus_line{1,2};
            new_feeder_line=currentbest_bus_line{1,3};
            new_OD_Kpath_set=currentbest_OD_Kpath_set;
            new_original_line=currentbest_original_line;
            new_inline_transfer=currentbest_inline_transfer;
            new_arc_transfer=currentbest_arc_transfer;
            new_Num_transfer=currentbest_Num_transfer;
            new_invehicle_arc=currentbest_invehicle_arc;
            new_invehicle_arc_line=currentbest_invehicle_arc_line;
            value_update=0;
        end
    else
        new_trunk_line=currentbest_bus_line{1,1};
        new_main_line=currentbest_bus_line{1,2};
        new_feeder_line=currentbest_bus_line{1,3};
        new_OD_Kpath_set=currentbest_OD_Kpath_set;
        new_original_line=currentbest_original_line;
        new_inline_transfer=currentbest_inline_transfer;
        new_arc_transfer=currentbest_arc_transfer;
        new_Num_transfer=currentbest_Num_transfer;
        new_invehicle_arc=currentbest_invehicle_arc;
        new_invehicle_arc_line=currentbest_invehicle_arc_line;
        value_update=0;
    end
end
new_num_trunk_line=size(new_trunk_line,2);
new_num_main_line=size(new_main_line,2);
new_num_feeder_line=size(new_feeder_line,2);
new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;