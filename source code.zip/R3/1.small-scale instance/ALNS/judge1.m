function value1=judge1(trunk_line,main_line,feeder_line)   
global Max_trunk_line
global Max_main_line
global Max_feeder_line
Num_trunk_line=size(trunk_line,2);
Num_main_line=size(main_line,2);
Num_feeder_line=size(feeder_line,2);
if Num_trunk_line>Max_trunk_line||Num_main_line>Max_main_line||Num_feeder_line>Max_feeder_line
    value1=0;
else
    value1=1;
end