function [value,plat_line_bus]=judge_stop_line(trunk_line,main_line,feeder_line)
[Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
global N_platform Max_arc_line Bus_station
value_temp1=ones(1,N_platform);
value_temp2=ones(1,N_platform);
for i=1:N_platform
    if ismember(i,Bus_station)==1
        if size(plat_line_bus{1,i},2)>Max_arc_line
            value_temp1(1,i)=0;
        end
%         if size(plat_line_bus{1,i},2)==0
%             value_temp2(1,i)=0;
%         end
    end
end
if ismember(0,value_temp1)||ismember(0,value_temp2)
    value=0;
else
    value=1;
end