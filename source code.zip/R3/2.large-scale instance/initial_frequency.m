function bus_frequency=initial_frequency(Num_bus_line)
bus_frequency=zeros(1,Num_bus_line);
global Fmin
for i=1:size(bus_frequency,2)
    bus_frequency(1,i)=Fmin;
end