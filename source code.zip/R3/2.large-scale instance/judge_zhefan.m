function value=judge_zhefan(bus_line)
global road_matrix length_road_matrix
new_bus_line=[];
for g=1:size(bus_line,2)-1
    i=bus_line(1,g);
    j=bus_line(1,g+1);
    [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
    new_bus_line=[new_bus_line,shortest_path_temp];   
end
new_bus_line=unique(new_bus_line,'stable');
value1=1;
for i=1:size(new_bus_line,2)-2
    if (road_matrix(new_bus_line(1,i),new_bus_line(1,i+1))==1)&&(road_matrix(new_bus_line(1,i),new_bus_line(1,i+2))==1)&&(road_matrix(new_bus_line(1,i+1),new_bus_line(1,i+2))==1)
        value1=0;
        break
    end
end
value2_temp=1;
pair2={[19,20,32,33],[17,18,33,34],[26,27,48,55],[14,42,41,65],[7,9,10,50],[7,6,10,50],[10,50,6,9]};
for i=1:size(pair2,2)
    vec=ismember(pair2{1,i},new_bus_line);
    if sum(vec)==size(pair2{1,i},2)
        value2_temp=0;
        break
    end
end
if value2_temp==1
    value2=1;
else
    value2=0;
end
pair31={[50,7,9,6],[50,7,6,9],[7,50,9,6],[7,50,6,9],[6,9,7,50],[6,9,50,7],[9,6,7,50],[9,6,50,7],[9,7,6,50],[9,7,50,6],[7,9,50,6],[7,9,6,50],[6,50,9,7],[6,50,7,9],[50,6,9,7],[50,6,7,9]};
pair32={[10,7,9,6],[10,7,6,9],[7,10,9,6],[7,10,6,9],[9,6,7,10],[9,6,10,7],[6,9,7,10],[6,9,10,7],[7,9,10,6],[7,9,6,10],[9,7,10,6],[9,7,6,10],[10,6,7,9],[10,6,9,7],[6,10,7,9],[6,10,9,7]};
pair33={[16,36,35,15],[16,36,15,35],[36,16,35,15],[36,16,15,35],[15,35,16,36],[15,35,36,16],[35,15,16,36],[35,15,36,16],[35,16,36,15],[35,16,15,36],[16,35,36,15],[16,35,15,36],[15,36,35,16],[15,36,16,35],[36,15,35,16],[36,15,16,35]};
pair34={[29,16,28,17],[29,16,17,28],[16,29,28,17],[16,29,17,28],[28,17,16,29],[28,17,29,16],[17,28,16,29],[17,28,29,16],[17,29,16,28],[17,29,28,16],[29,17,16,28],[29,17,28,16],[16,28,29,17],[16,28,17,29],[28,16,29,17],[28,16,17,29]};
pair3=[pair31,pair32,pair33,pair34];
value3_temp=ones(1,size(pair3,2));
value3_temp_temp=zeros(1,size(pair3,2));
value3_temp_temp_scequence=zeros(1,size(pair3,2));
for i=1:size(pair3,2)
    [vec,vec_position]=ismember(pair3{1,i},new_bus_line);
    if sum(vec)==size(pair3{1,i},2)
        value3_temp_temp(1,i)=1;
        temp=ones(1,size(vec,2));
        for j=1:size(vec_position,2)-1
            if vec_position(1,j)>vec_position(1,j+1)
                temp(1,j)=0;
            end
        end
        if sum(temp)==size(vec_position,2)
            value3_temp_temp_scequence(1,i)=1;
        end
    end
    if value3_temp_temp_scequence(1,i)==1
        value3_temp(1,i)=0;
        break
    end
end
if ismember(0,value3_temp)
    value3=0;
else
    value3=1;
end
if value1==1&&value2==1&&value3==1
    value=1;
else
    value=0;
end



















