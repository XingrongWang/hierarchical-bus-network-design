function [original_line_temp,inline_transfer_temp,arc_temp,line_arc_temp,arc_walk_temp,invehicle_arc_temp,invehicle_arc_line_temp,arc_transfer_non_walk_temp,arc_transfer_walk_temp,Num_transfer_temp]=calculate_path_attribute(path,Num_total_line,new_total_line) 
global N_platform
walk_line=[1:N_platform];
arc_transfer_non_walk_temp=[];
arc_transfer_walk_temp=[];
arc_transfer_temp=[];
inline_transfer_temp=[];
original_line_temp=0;
for n=1:Num_total_line
    if ismember(path(1,2),new_total_line{1,n}(1,:))
        original_line_temp=n;
        break
    end
end    
for i=2:size(path,2)-2
    location_line_i=0;
    location_line_i_nextnode=0;
    if ismember(path(1,i),walk_line)
        location_line_i=0;
    else
        for n=1:Num_total_line
            if ismember(path(1,i),new_total_line{1,n}(1,:))
                location_line_i=n;
            end
        end
    end
    if ismember(path(1,i+1),walk_line)
        location_line_i_nextnode=0;
    else
        for n=1:Num_total_line
            if ismember(path(1,i+1),new_total_line{1,n}(1,:))
                location_line_i_nextnode=n;
            end
        end
    end 
    if location_line_i~=location_line_i_nextnode
        arc_transfer_temp=[arc_transfer_temp;path(1,i),path(1,i+1)];
    end
    if location_line_i~=location_line_i_nextnode&&location_line_i~=0&&location_line_i_nextnode~=0
        arc_transfer_non_walk_temp=[arc_transfer_non_walk_temp;path(1,i),path(1,i+1)];
    else
        if location_line_i~=location_line_i_nextnode&&(location_line_i==0||location_line_i_nextnode==0)
            arc_transfer_walk_temp=[arc_transfer_walk_temp;path(1,i),path(1,i+1)];
        end
    end
    if location_line_i~=location_line_i_nextnode&&location_line_i_nextnode~=0
        inline_transfer_temp=[inline_transfer_temp,location_line_i_nextnode];
    end
end
arc_temp=cell(1,size(arc_transfer_temp,1)+1);
if size(arc_transfer_temp,1)==0
    arc_temp{1,1}=path(1,1:size(path,2));
else
    for i=1:size(arc_transfer_temp,1)+1
        if i==1
            arc_temp{1,i}=path(1,1:find(path==arc_transfer_temp(i,1)));
        else
            if i==size(arc_transfer_temp,1)+1
                arc_temp{1,i}=path(1,find(path==arc_transfer_temp(i-1,2)):size(path,2));
            else
                arc_temp{1,i}=path(1,find(path==arc_transfer_temp(i-1,2)):find(path==arc_transfer_temp(i,1)));
            end
        end
    end
end
line_arc_temp=zeros(1,size(arc_transfer_temp,1)+1);
for i=1:size(arc_transfer_temp,1)+1
    if ismember(arc_temp{1,i}(1,2),[1:N_platform])
        line_arc_temp(1,i)=0;
    else
        for n=1:Num_total_line
            if ismember(arc_temp{1,i}(1,2),new_total_line{1,n}(1,:))
                line_arc_temp(1,i)=n;
            end
        end
    end
end
arc_walk_temp={};
for i=1:size(arc_transfer_temp,1)+1
    if ismember(arc_temp{1,i}(1,1),[1:N_platform])==1&&ismember(arc_temp{1,i}(1,2),[1:N_platform])==1
        arc_walk_temp=[arc_walk_temp,arc_temp{1,i}];
    end
end
invehicle_arc_temp={};
for i=1:size(arc_transfer_temp,1)+1
    if ismember(arc_temp{1,i}(1,2),[1:N_platform])==0
        invehicle_arc_temp=[invehicle_arc_temp,arc_temp{1,i}];
    end
end
position=find(line_arc_temp~=0);
invehicle_arc_line_temp=[];
for i=1:size(position,2)
invehicle_arc_line_temp(1,i)=line_arc_temp(1,position(1,i));
end

for i=1:size(invehicle_arc_temp,2)
    temp=invehicle_arc_temp{1,i};
    if ismember(temp(1,1),[1:N_platform])&&ismember(temp(1,size(temp,2)),[1:N_platform])
        invehicle_arc_temp{1,i}=temp(2:size(temp,2)-1);
    else
        if ismember(temp(1,1),[1:N_platform])
             invehicle_arc_temp{1,i}=temp(2:size(temp,2));
        else
            if ismember(temp(1,size(temp,2)),[1:N_platform])
                invehicle_arc_temp{1,i}=temp(1:size(temp,2)-1);
            end
        end
    end
end
Num_transfer_temp=max(size(invehicle_arc_temp,2)-1,0);
    
    








