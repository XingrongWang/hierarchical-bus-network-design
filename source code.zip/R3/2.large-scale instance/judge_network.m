function [value,value1,value3,value5,value6,infeasible_od1,infeasible_od2,plat_line,plat_line_bus,plat_line_bus_actual]=judge_network(trunk_line,main_line,feeder_line)
value=0;
value1=0;
value3=0;
value5=0;
value6=0;
infeasible_od1={};
infeasible_od2={};
plat_line={};
plat_line_bus={};
plat_line_bus_actual={};
value1=judge1(trunk_line,main_line,feeder_line);
if value1==1
    value3=judge3(path,bus_line,add_kind);
    if value3==1
        [value5,plat_line_bus,plat_line_bus_actual]=judge5(trunk_line,main_line,feeder_line);
        if value5==1
            [value6,infeasible_od1,infeasible_od2,plat_line]=judge6(trunk_line,main_line,feeder_line);
        end
    end
end
if value1==1&&value3==1&&value5==1&&value6==1
    value=1;
end
            