function [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_objective,new_cost,new_travel_time,new_wait_time,new_invehicle_time,new_transfer_time,new_walk_time,new_fa1,new_fa2,new_fa3,new_fa4,new_Num_bus,new_Bus_frequency]=operator7(currentbest_bus_line)
global N_platform  Metro_station KK OD Bus_station Metro_station_solo
global Max_trunk_line Max_main_line Max_feeder_line
global trunk_matrix length_trunk_matrix
global main_feeder_matrix length_main_feeder_matrix
global currentbest_objective currentbest_cost currentbest_total_travel_time currentbest_total_wait_time currentbest_total_invehicle_time currentbest_total_transfer_time currentbest_total_walk_time currentbest_fa1 currentbest_fa2 currentbest_fa3 currentbest_fa4 currentbest_Num_bus  currentbest_bus_frequency
trunk_line=currentbest_bus_line{1,1};
main_line=currentbest_bus_line{1,2};
feeder_line=currentbest_bus_line{1,3};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
all_line=[trunk_line,main_line,feeder_line];
num_line=num_trunk_line+num_main_line+num_feeder_line;
add_line=[];
if num_trunk_line<Max_trunk_line
    add_line=[add_line,1];
end
if num_main_line<Max_main_line
    add_line=[add_line,2];
end
if num_feeder_line<Max_feeder_line
    add_line=[add_line,3];
end
if size(add_line,2)==0
    value_update=0;
    new_trunk_line=currentbest_bus_line{1,1};
    new_main_line=currentbest_bus_line{1,2};
    new_feeder_line=currentbest_bus_line{1,3};
    new_num_trunk_line=size(new_trunk_line,2);
    new_num_main_line=size(new_main_line,2);
    new_num_feeder_line=size(new_feeder_line,2);
    new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
    new_objective=currentbest_objective;
    new_cost=currentbest_cost;
    new_travel_time=currentbest_total_travel_time;
    new_wait_time=currentbest_total_wait_time;
    new_invehicle_time=currentbest_total_invehicle_time;
    new_transfer_time=currentbest_total_transfer_time;
    new_walk_time=currentbest_total_walk_time;
    new_fa1=currentbest_fa1;
    new_fa2=currentbest_fa2;
    new_fa3=currentbest_fa3;
    new_fa4=currentbest_fa4;
    new_Num_bus=currentbest_Num_bus;
    new_Bus_frequency=currentbest_bus_frequency;
else
    rest=setdiff(Bus_station,Metro_station_solo);
    add_position=ceil(rand*size(add_line,2));
    add_kind=add_line(1,add_position);
    if add_kind==1
        ls=0;
        while ls<1
            temp=randperm(size(rest,2));
            s=rest(1,temp(1,1));
            s_line=[];
            for i=1:size(all_line,2)
                if ismember (s,all_line{1,i})
                    s_line=[s_line,i];
                end
            end
            if size(s_line,2)>0
                s_line_temp=randperm(size(s_line,2));
                ls=s_line(1,s_line_temp(1,1));
            end
        end
        ls_station=all_line{1,ls};
        volume1=zeros(1,num_line);
        volume2=zeros(1,num_line);
        for i=1:num_line
            if i~=ls
                i_station=all_line{1,i};
                for j=1:size(ls_station,2)
                    for k=1:size(i_station,2)
                        volume1(1,i)=volume1(1,i)+OD(ls_station(1,j),i_station(1,k));
                        volume2(1,i)=volume2(1,i)+OD(i_station(1,k),ls_station(1,j));
                    end
                end
            end
        end
        volume=[volume1;volume2];
        [x,y]=find(volume==max(max(volume)));
        y_station=all_line{1,y};
        y_station=setdiff(y_station,s);
        volume_station1=zeros(1,size(y_station,2));
        volume_station2=zeros(1,size(y_station,2));
        for i=1:size(y_station,2)
            for j=1:size(ls_station,2)
                volume_station1(1,i)=volume_station1(1,i)+OD(y_station(1,i),ls_station(1,j));
                volume_station2(1,i)=volume_station2(1,i)+OD(ls_station(1,j),y_station(1,i));
            end
        end
        volume_station=[volume_station1;volume_station2];
        volume_station_temp=[];
        for i=1:size(volume_station,2)
            volume_station_temp=[volume_station_temp,max(volume_station(1,i),volume_station(2,i))];
        end
        [max_volume,max_position]=sort(volume_station_temp,'descend');
        for i=1:size(max_position,2)
            e=y_station(1,max_position(1,i));
            [add_path_temp,length_path_temp]=Kshortest_line(trunk_matrix,length_trunk_matrix,s,e);
            for k=1:KK
                value_length=judge_length(length_path_temp(1,k),add_kind);
                value_loop=judge_loop(add_path_temp{1,k});
                value_zhefan=judge_zhefan(add_path_temp{1,k});
                if value_length==1&&value_loop==1&&value_zhefan==1
                    bus_line_temp=add_path_temp{1,k};
                    break
                end
            end
            if value_length==1&&value_loop==1&&value_zhefan==1
                break
            end
        end
        if value_length==0||value_loop==0||value_zhefan==0
            bus_line_temp=[];
        end
    else
        if add_kind==2
            ls=0;
            s_line=[];
            while ls<1
                temp=randperm(size(rest,2));
                s=rest(1,temp(1,1));
                for i=1:size(all_line,2)
                    if ismember (s,all_line{1,i})
                        s_line=[s_line,i];
                    end
                end
                if size(s_line,2)>0
                s_line_temp=randperm(size(s_line,2));
                ls=s_line(1,s_line_temp(1,1));
                end
            end
            ls_station=all_line{1,ls};
            volume1=zeros(1,num_line);
            volume2=zeros(1,num_line);
            for i=1:num_line
                if i~=ls
                    i_station=all_line{1,i};
                    for j=1:size(ls_station,2)
                        for k=1:size(i_station,2)
                            volume1(1,i)=volume1(1,i)+OD(ls_station(1,j),i_station(1,k));
                            volume2(1,i)=volume2(1,i)+OD(i_station(1,k),ls_station(1,j));
                        end
                    end
                end
            end
            volume=[volume1;volume2];
            [x,y]=find(volume==max(max(volume)));
            y_station=all_line{1,y};
            y_station=setdiff(y_station,s);
            volume_station1=zeros(1,size(y_station,2));
            volume_station2=zeros(1,size(y_station,2));
            for i=1:size(y_station,2)
                for j=1:size(ls_station,2)
                    volume_station1(1,i)=volume_station1(1,i)+OD(y_station(1,i),ls_station(1,j));
                    volume_station2(1,i)=volume_station2(1,i)+OD(ls_station(1,j),y_station(1,i));
                end
            end
            volume_station=[volume_station1;volume_station2];
            volume_station_temp=[];
            for i=1:size(volume_station,2)
                volume_station_temp=[volume_station_temp,max(volume_station(1,i),volume_station(2,i))];
            end
            [max_volume,max_position]=sort(volume_station_temp,'descend');
            for i=1:size(max_position,2)
                e=y_station(1,max_position(1,i));
                [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
                for k=1:KK
                    value_length=judge_length(length_path_temp(1,k),add_kind);
                    value_loop=judge_loop(add_path_temp{1,k});
                    value_zhefan=judge_zhefan(add_path_temp{1,k});
                    if value_length==1&&value_loop==1&&value_zhefan==1
                        bus_line_temp=add_path_temp{1,k};
                        break
                    end
                end
                if value_length==1&&value_loop==1&&value_zhefan==1
                    break
                end
            end
            if value_length==0||value_loop==0||value_zhefan==0
                bus_line_temp=[];
            end
        else
            if add_kind==3
                s=Metro_station(1,ceil(rand*size(Metro_station,2)));
                volume1=zeros(1,num_line);
                volume2=zeros(1,num_line);
                for i=1:num_line
                    i_station=all_line{1,i};
                    for k=1:size(i_station,2)
                        volume1(1,i)=volume1(1,i)+OD(s,i_station(1,k));
                        volume2(1,i)=volume2(1,i)+OD(i_station(1,k),s);
                    end
                end
                volume=[volume1;volume2];
                [x,y]=find(volume==max(max(volume)));
                y_station=all_line{1,y};
                y_station=setdiff(y_station,s);
                volume_station1=zeros(1,size(y_station,2));
                volume_station2=zeros(1,size(y_station,2));
                for i=1:size(y_station,2)
                    volume_station1(1,i)=volume_station1(1,i)+OD(y_station(1,i),s);
                    volume_station2(1,i)=volume_station2(1,i)+OD(s,y_station(1,i));
                end
                volume_station=[volume_station1;volume_station2];
                volume_station_temp=[];
                for i=1:size(volume_station,2)
                    volume_station_temp=[volume_station_temp,max(volume_station(1,i),volume_station(2,i))];
                end
                [max_volume,max_position]=sort(volume_station_temp,'descend');
                for i=1:size(y_station,2)
                    e=y_station(1,max_position(1,i));
                    [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
                    for k=1:KK
                        value_length=judge_length(length_path_temp(1,k),add_kind);
                        value_loop=judge_loop(add_path_temp{1,k});
                        value_zhefan=judge_zhefan(add_path_temp{1,k});
                        if value_length==1&&value_loop==1&&value_zhefan==1
                            bus_line_temp=add_path_temp{1,k};
                            break
                        end
                    end
                    if value_length==1&&value_loop==1&&value_zhefan==1
                        break
                    end
                end
                if value_length==0||value_loop==0||value_zhefan==0
                    bus_line_temp=[];
                end
            end
        end
    end
    if size(bus_line_temp,2)>0
        if add_kind==1
            trunk_line=[trunk_line,bus_line_temp];
        else
            if add_kind==2
                main_line=[main_line,bus_line_temp];
            else
                if add_kind==3
                    feeder_line=[feeder_line,bus_line_temp];
                end
            end
        end
        value_contain=judge_contain(bus_line_temp,currentbest_bus_line,add_kind);
        [value_stop_line,plat_line_bus]=judge_stop_line(trunk_line,main_line,feeder_line);
        if value_contain==1&&value_stop_line==1
            [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
            [OD_Kpath_set,original_line,inline_transfer,arc,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);
            value_connection_temp=ones(N_platform,N_platform);
            for s=1:N_platform
                for e=1:N_platform
                    if e~=s&&OD(s,e)~=0
                        if ismember(inf,OD_Kpath_set{s,e}{1,1})
                            value_connection_temp(s,e)=0;
                        end
                    end
                end
            end
            if ismember(0,value_connection_temp)
                value_connection=0;
            else
                value_connection=1;
            end
            if  value_connection==1
                value_update=1;
                new_trunk_line=trunk_line;
                new_main_line=main_line;
                new_feeder_line=feeder_line;
                new_num_trunk_line=size(new_trunk_line,2);
                new_num_main_line=size(new_main_line,2);
                new_num_feeder_line=size(new_feeder_line,2);
                new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
                [new_objective,new_cost,new_travel_time,new_wait_time,new_invehicle_time,new_transfer_time,new_walk_time,new_fa1,new_fa2,new_fa3,new_fa4,new_Num_bus,new_Bus_frequency]=cal_objective_frequency(Num_total_line,new_num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer);
            else
                value_update=0;
                new_trunk_line=currentbest_bus_line{1,1};
                new_main_line=currentbest_bus_line{1,2};
                new_feeder_line=currentbest_bus_line{1,3};
                new_num_trunk_line=size(new_trunk_line,2);
                new_num_main_line=size(new_main_line,2);
                new_num_feeder_line=size(new_feeder_line,2);
                new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
                new_objective=currentbest_objective;
                new_cost=currentbest_cost;
                new_travel_time=currentbest_total_travel_time;
                new_wait_time=currentbest_total_wait_time;
                new_invehicle_time=currentbest_total_invehicle_time;
                new_transfer_time=currentbest_total_transfer_time;
                new_walk_time=currentbest_total_walk_time;
                new_fa1=currentbest_fa1;
                new_fa2=currentbest_fa2;
                new_fa3=currentbest_fa3;
                new_fa4=currentbest_fa4;
                new_Num_bus=currentbest_Num_bus;
                new_Bus_frequency=currentbest_bus_frequency;
            end
        else
            value_update=0;
            new_trunk_line=currentbest_bus_line{1,1};
            new_main_line=currentbest_bus_line{1,2};
            new_feeder_line=currentbest_bus_line{1,3};
            new_num_trunk_line=size(new_trunk_line,2);
            new_num_main_line=size(new_main_line,2);
            new_num_feeder_line=size(new_feeder_line,2);
            new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
            new_objective=currentbest_objective;
            new_cost=currentbest_cost;
            new_travel_time=currentbest_total_travel_time;
            new_wait_time=currentbest_total_wait_time;
            new_invehicle_time=currentbest_total_invehicle_time;
            new_transfer_time=currentbest_total_transfer_time;
            new_walk_time=currentbest_total_walk_time;
            new_fa1=currentbest_fa1;
            new_fa2=currentbest_fa2;
            new_fa3=currentbest_fa3;
            new_fa4=currentbest_fa4;
            new_Num_bus=currentbest_Num_bus;
            new_Bus_frequency=currentbest_bus_frequency;
        end
    else
        value_update=0;
        new_trunk_line=currentbest_bus_line{1,1};
        new_main_line=currentbest_bus_line{1,2};
        new_feeder_line=currentbest_bus_line{1,3};
        new_num_trunk_line=size(new_trunk_line,2);
        new_num_main_line=size(new_main_line,2);
        new_num_feeder_line=size(new_feeder_line,2);
        new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
        new_objective=currentbest_objective;
        new_cost=currentbest_cost;
        new_travel_time=currentbest_total_travel_time;
        new_wait_time=currentbest_total_wait_time;
        new_invehicle_time=currentbest_total_invehicle_time;
        new_transfer_time=currentbest_total_transfer_time;
        new_walk_time=currentbest_total_walk_time;
        new_fa1=currentbest_fa1;
        new_fa2=currentbest_fa2;
        new_fa3=currentbest_fa3;
        new_fa4=currentbest_fa4;
        new_Num_bus=currentbest_Num_bus;
        new_Bus_frequency=currentbest_bus_frequency;
    end
end

