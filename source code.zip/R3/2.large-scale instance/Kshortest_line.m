%和Kshortest_path不同，不用判断换乘的有效性，只是生成od对间的K条公交线路，在最短线路的一定系数内
function [k_shortest_path,k_time_path]=Kshortest_line(A,weight,s,e)
global KK
k_shortest_path=cell(1,KK);
k_time_path=zeros(1,KK);
weight_temp=weight;
k=1;
while k<=KK
    if k==1
        [k_shortest_path{1,k},k_time_path(1,k)]=shortest_path(A,weight_temp,s,e);
    else
        n_node=size(k_shortest_path{1,k-1}(1,:),2);
        if mod(n_node,2)==0
            weight_temp(k_shortest_path{1,k-1}(1,n_node/2),k_shortest_path{1,k-1}(1,n_node/2+1))=inf;
        else
            weight_temp(k_shortest_path{1,k-1}(1,(n_node+1)/2-1),k_shortest_path{1,k-1}(1,(n_node+1)/2))=inf;
        end
        [k_shortest_path{1,k},k_time_path(1,k)]=shortest_path(A,weight_temp,s,e);
    end
    k=k+1;
end
