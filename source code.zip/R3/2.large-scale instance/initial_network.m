function [trunk_line,main_line,feeder_line,Num_bus_line]=initial_network
trunk_line={};
main_line={[1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21	22],[23 24 25 26 27	28	29	30	31	32	33	34	35	36	37	38	39	40	41	42	43 44],[45 46 22 47 37 36 15 48 26 25 24 23 49 12 50 7 8 51 52 53 54],[44	43 42 41 40 39 38 37 36 15 48 55 56 57 58 59 60 61 62 63 64],[14 65 26 55 56 66 67 61 62 63 64 68 69],[70 71 72 73 74 75 76 77 59 56 78 79 24 23]};
feeder_line={};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
Num_bus_line=num_trunk_line+num_main_line+num_feeder_line;

