function [weight_od_avg_travel_time,weight_od_avg_wait_time,weight_od_avg_invehicle_time,weight_od_avg_transfer_time]=cal_weight_OD_objective(travel_time,wait_time,invehicle_time,transfer_time,walk_time,utility)
global N_platform
global K
global theta
global OD
weight_od_avg_travel_time=zeros(N_platform,N_platform);
weight_od_avg_wait_time=zeros(N_platform,N_platform);
weight_od_avg_invehicle_time=zeros(N_platform,N_platform);
weight_od_avg_transfer_time=zeros(N_platform,N_platform);
p=zeros(N_platform,N_platform,K);
for s=1:N_platform
    for e=1:N_platform
        if s~=e
            if OD(s,e)~=0
                p_leiji=0;
                for k=1:K
                    if k<K
                        p(s,e,k)=exp(-theta*utility(s,e,k)/min(utility(s,e,:)))/sum(exp(-theta*utility(s,e,:)/min(utility(s,e,:))));
                        weight_od_avg_travel_time(s,e)=weight_od_avg_travel_time(s,e)+travel_time(s,e,k)*p(s,e,k);
                        weight_od_avg_wait_time(s,e)=weight_od_avg_wait_time(s,e)+wait_time(s,e,k)*p(s,e,k);
                        weight_od_avg_invehicle_time(s,e)=weight_od_avg_invehicle_time(s,e)+invehicle_time(s,e,k)*p(s,e,k);
                        weight_od_avg_transfer_time(s,e)=weight_od_avg_transfer_time(s,e)+(transfer_time(s,e,k)+walk_time(s,e,k))*p(s,e,k);
                        p_leiji=p_leiji+p(s,e,k);
                    else
                        if k==K
                            p(s,e,k)=1-p_leiji;
                            weight_od_avg_travel_time(s,e)=weight_od_avg_travel_time(s,e)+travel_time(s,e,k)*p(s,e,k);
                            weight_od_avg_wait_time(s,e)=weight_od_avg_wait_time(s,e)+wait_time(s,e,k)*p(s,e,k);
                            weight_od_avg_invehicle_time(s,e)=weight_od_avg_invehicle_time(s,e)+invehicle_time(s,e,k)*p(s,e,k);
                            weight_od_avg_transfer_time(s,e)=weight_od_avg_transfer_time(s,e)+(transfer_time(s,e,k)+walk_time(s,e,k))*p(s,e,k);
                        end
                    end
                end
            end
        end
    end
end
