function value=judge_contain(path,bus_line,add_kind)
trunk_line=bus_line{1,1};
main_line=bus_line{1,2};
feeder_line=bus_line{1,3};
main_feeder_line=[bus_line{1,2},bus_line{1,3}];
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
if add_kind==1
    value_temp=zeros(1,2*num_trunk_line);
    for n=1:num_trunk_line
        value_temp1=ismember(path,trunk_line{1,n});
        if all(value_temp1==1)
            value_temp(1,n)=1;
        end
        value_temp2=ismember(trunk_line{1,n},path);
        if all(value_temp2==1)
            value_temp(1,num_trunk_line+n)=1;
        end
    end
    if ismember(1,value_temp)
        value=0;
    else
        value=1;
    end
else
    if add_kind==2||add_kind==3
        value_temp=zeros(1,2*(num_main_line+num_feeder_line));
        for n=1:num_main_line+num_feeder_line
            value_temp1=ismember(path,main_feeder_line{1,n});
            if all(value_temp1==1)
                value_temp(1,n)=1;
            end
            value_temp2=ismember(main_feeder_line{1,n},path);
            if all(value_temp2==1)
                value_temp(1,num_main_line+num_feeder_line+n)=1;
            end
        end
        if ismember(1,value_temp)
            value=0;
        else
            value=1;
        end
    end
end
      