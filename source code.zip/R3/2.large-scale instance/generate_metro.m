function [metro_matrix,length_metro_matrix,time_metro_matrix]=generate_metro
global N_platform Metro_line Num_metro_line distance_metro_line v_metro
metro_matrix=zeros(N_platform,N_platform);
length_metro_matrix=zeros(N_platform,N_platform);
time_metro_matrix=zeros(N_platform,N_platform);
for m=1:Num_metro_line
    for s=1:size(Metro_line{1,m},2)-1
        for ss=s+1:size(Metro_line{1,m},2)
        node1=Metro_line{1,m}(1,s);
        node2=Metro_line{1,m}(1,ss);
        metro_matrix(node1,node2)=1;
        metro_matrix(node2,node1)=1;
        length_metro_matrix(node1,node2)=distance_metro_line{1,m}(1,s);
        length_metro_matrix(node2,node1)=distance_metro_line{1,m}(1,s);
        time_metro_matrix(node1,node2)=length_metro_matrix(node1,node2)/v_metro;
        time_metro_matrix(node2,node1)=length_metro_matrix(node2,node1)/v_metro;
        end
    end
end
for i=1:N_platform
    for j=1:N_platform
        if length_metro_matrix(i,j)==0
            length_metro_matrix(i,j)=10000;
            time_metro_matrix(i,j)=10000;
        end
    end
end
            