function length=cal_length(best_bus_line)
global length_road_matrix road_matrix
line=best_bus_line;
num_line=size(line,2);
length=zeros(1,num_line);
real_line=cell(1,num_line);
space=cell(1,num_line);
for m=1:num_line
    real_line{1,m}=[];
    space{1,m}=[];
    for i=1:size(line{1,m},2)-1
        node1=line{1,m}(1,i);
        node2=line{1,m}(1,i+1);
        [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,node1,node2);
        real_line{1,m}=[real_line{1,m},shortest_path_temp];
        space{1,m}=[space{1,m},length_path_temp];
    end
    real_line{1,m}=unique(real_line{1,m},'stable');
end
for m=1:num_line
    for i=1:size(real_line{1,m},2)-1
        node1=real_line{1,m}(1,i);
        node2=real_line{1,m}(1,i+1);
        length(1,m)=length(1,m)+length_road_matrix(node1,node2);
    end
end