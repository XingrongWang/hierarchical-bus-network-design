function value=judge_transfer(Num_transfer,line_arc_temp,invehicle_arc_line_temp,Num_total_line)
global Num_metro_line
value=0;
temp=unique(invehicle_arc_line_temp);
if size(temp,2)==size(invehicle_arc_line_temp,2)
    temp_value=1;
else
    temp_value=0;
end
if Num_transfer<=1&&temp_value==1
    value=1;
else
    if Num_transfer==2&&temp_value==1
        if ismember(line_arc_temp(1,1),[1:Num_metro_line])&&line_arc_temp(1,2)==0&&ismember(line_arc_temp(1,3),[1:Num_metro_line])
            value=0;
        else
            if ismember(line_arc_temp(1,1),[1:Num_metro_line])&&ismember(line_arc_temp(1,2),[Num_metro_line+1:Num_total_line])&&ismember(line_arc_temp(1,3),[1:Num_metro_line])
                value=0;
            else
                if ismember(invehicle_arc_line_temp(1,1),[1:Num_metro_line])&&ismember(invehicle_arc_line_temp(1,2),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line_temp(1,3),[1:Num_metro_line])
                    value=0;
                else
                    value=1;
                end
            end
        end
    else
        if Num_transfer==3&&temp_value==1
            if (ismember(line_arc_temp(1,1),[1:Num_metro_line])&&line_arc_temp(1,2)==0&&ismember(line_arc_temp(1,3),[1:Num_metro_line]))||(ismember(line_arc_temp(1,1),[1:Num_metro_line])&&ismember(line_arc_temp(1,2),[Num_metro_line+1:Num_total_line])&&ismember(line_arc_temp(1,3),[1:Num_metro_line]))
                value=0;
            else
                if (ismember(line_arc_temp(1,2),[1:Num_metro_line])&&line_arc_temp(1,3)==0&&ismember(line_arc_temp(1,4),[1:Num_metro_line]))||(ismember(line_arc_temp(1,2),[1:Num_metro_line])&&ismember(line_arc_temp(1,3),[Num_metro_line+1:Num_total_line])&&ismember(line_arc_temp(1,4),[1:Num_metro_line]))
                    value=0;
                else
                    if ismember(line_arc_temp(1,1),[1:Num_metro_line])&&ismember(line_arc_temp(1,2),[Num_metro_line+1:Num_total_line])&&ismember(line_arc_temp(1,3),[Num_metro_line+1:Num_total_line])&&ismember(line_arc_temp(1,4),[1:Num_metro_line])
                        value=0;
                    else
                        if ismember(line_arc_temp(1,1),[1:Num_metro_line])&&ismember(line_arc_temp(1,2),[Num_metro_line+1:Num_total_line])&&line_arc_temp(1,3)==0&&ismember(line_arc_temp(1,4),[1:Num_metro_line])
                            value=0;
                        else
                            if ismember(line_arc_temp(1,1),[1:Num_metro_line])&&line_arc_temp(1,2)==0&&ismember(line_arc_temp(1,3),[Num_metro_line+1:Num_total_line])&&ismember(line_arc_temp(1,4),[1:Num_metro_line])
                                value=0;
                            else
                                if ismember(line_arc_temp(1,1),[1:Num_metro_line])&&line_arc_temp(1,2)==0&&line_arc_temp(1,3)==0&&ismember(line_arc_temp(1,4),[1:Num_metro_line])
                                    value=0;
                                else
                                    if (ismember(invehicle_arc_line_temp(1,1),[1:Num_metro_line])&&ismember(invehicle_arc_line_temp(1,2),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line_temp(1,3),[1:Num_metro_line]))||(ismember(invehicle_arc_line_temp(1,2),[1:Num_metro_line])&&ismember(invehicle_arc_line_temp(1,3),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line_temp(1,4),[1:Num_metro_line]))||(ismember(invehicle_arc_line_temp(1,1),[1:Num_metro_line])&&ismember(invehicle_arc_line_temp(1,2),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line_temp(1,3),[Num_metro_line+1:Num_total_line])&&ismember(invehicle_arc_line_temp(1,4),[1:Num_metro_line]))
                                        value=0;
                                    else
                                        value=1;
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end



