function [Objective,Cost,Total_travel_time,Total_wait_time,Total_invehicle_time,Total_transfer_time,Total_walk_time,Fa1,Fa2,Fa3,Fa4,Num_bus,Bus_frequency]=cal_objective_frequency(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer)
global N_bus Fmin Fmax
N_bus_min=zeros(1,Num_bus_line);
N_bus_max=zeros(1,Num_bus_line);
current_N_bus=zeros(1,Num_bus_line);
current_bus_frequency=zeros(1,Num_bus_line);
for i=1:Num_bus_line
    N_bus_min(1,i)=ceil(Fmin*2*time_bus_line(1,i));
    N_bus_max(1,i)=ceil(Fmax*2*time_bus_line(1,i));
end
N_max_total=min(N_bus,sum(N_bus_max(1,:)));
N_bus_total=N_max_total;
for j=1:Num_bus_line
    current_N_bus(1,j)=N_bus_min(1,j);
end
rest_N_bus=N_bus_total-sum(current_N_bus);
j=1;
while rest_N_bus>0
    if current_N_bus(1,j)<N_bus_max(1,j)
        current_N_bus(1,j)=current_N_bus(1,j)+1;
        rest_N_bus=rest_N_bus-1;
        j=j+1;
    else
        j=j+1;
    end
    if j==Num_bus_line+1
        j=1;
    end
end
for j=1:Num_bus_line
    current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
end
[utility,travel_time,wait_time,invehicle_time,transfer_time,walk_time]=cal_utility(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer,current_bus_frequency);
[OD_Kpath_demand,route_demand_max,route_demand1,route_demand2]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
[best_objective,best_cost,best_total_travel_time,best_total_wait_time,best_total_invehicle_time,best_total_transfer_time,best_total_walk_time,best_fa1,best_fa2,best_fa3,best_fa4]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,walk_time);
best_bus_frequency=current_bus_frequency;
best_N_bus=current_N_bus;
increase_node=ones(Num_bus_line,Num_bus_line);
for i=1:Num_bus_line
    increase_node(i,i)=0;
end
i=1;
while i<=Num_bus_line
    if  current_N_bus(1,i)>N_bus_min(1,i)
        j=1;
        %***********************
        while j<=Num_bus_line
            value_temp=0;
            if increase_node(i,j)>=1
                current_N_bus(1,i)=current_N_bus(1,i)-1;
                current_N_bus(1,j)=current_N_bus(1,j)+1;
                if current_N_bus(1,i)<N_bus_min(1,i)
                    current_N_bus(1,i)=current_N_bus(1,i)+1;
                    current_N_bus(1,j)=current_N_bus(1,j)-1;
                    i=i+1;
                    break
                else
                    if current_N_bus(1,j)>N_bus_max(1,j)
                        current_N_bus(1,i)=current_N_bus(1,i)+1;
                        current_N_bus(1,j)=current_N_bus(1,j)-1;
                        j=j+1;
                    else
                        current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                        current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                        [utility,travel_time,wait_time,invehicle_time,transfer_time,walk_time]=cal_utility(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer,current_bus_frequency);
                        [OD_Kpath_demand,route_demand_max,route_demand1,route_demand2]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
                        [objective,cost,total_travel_time,total_wait_time,total_invehicle_time,total_transfer_time,total_walk_time,fa1,fa2,fa3,fa4]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,walk_time);
                        if fa2<=best_fa2
                            value_temp=1;
                            best_objective=objective;
                            best_bus_frequency=current_bus_frequency;
                            best_N_bus=current_N_bus;
                            best_cost=cost;
                            best_total_travel_time=total_travel_time;
                            best_total_wait_time=total_wait_time;
                            best_total_invehicle_time=total_invehicle_time;
                            best_total_transfer_time=total_transfer_time;
                            best_total_walk_time=total_walk_time;
                            best_fa1=fa1;
                            best_fa2=fa2;
                            best_fa3=fa3;
                            best_fa4=fa4;
                        else
                            current_N_bus(1,i)=current_N_bus(1,i)+1;
                            current_N_bus(1,j)=current_N_bus(1,j)-1;
                            current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                            current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                            j=j+1;
                        end
                    end
                end%end if
            else%%if increase_node(i,j)>=1
                j=j+1;
            end%if increase_node(i,j)>=1
%             i
%             j
%             value_temp
%             current_N_bus
%             current_bus_frequency
        end%while j
        %***********************
        i=i+1;
        %****************************************
    else
        i=i+1;
    end%if
end%while i
%***************************************************************************************
increase_node=ones(Num_bus_line,Num_bus_line);%increase_node（i，j）取值为1意味着当i向j给予一个车底时，能使目标函数增加
for i=1:Num_bus_line
    increase_node(i,i)=0;
end
i=1;
while i<=Num_bus_line
    if  current_N_bus(1,i)>N_bus_min(1,i)
        j=1;
        %***********************
        while j<=Num_bus_line
            value_temp=0;
            if increase_node(i,j)>=1
                current_N_bus(1,i)=current_N_bus(1,i)-1;
                current_N_bus(1,j)=current_N_bus(1,j)+1;
                if current_N_bus(1,i)<N_bus_min(1,i)
                    current_N_bus(1,i)=current_N_bus(1,i)+1;
                    current_N_bus(1,j)=current_N_bus(1,j)-1;
                    i=i+1;
                    break
                else
                    if current_N_bus(1,j)>N_bus_max(1,j)
                        current_N_bus(1,i)=current_N_bus(1,i)+1;
                        current_N_bus(1,j)=current_N_bus(1,j)-1;
                        j=j+1;
                    else
                        current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                        current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                        [utility,travel_time,wait_time,invehicle_time,transfer_time,walk_time]=cal_utility(Num_total_line,Num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer,current_bus_frequency);
                        [OD_Kpath_demand,route_demand_max,route_demand1,route_demand2]=P_assignment(utility,Num_total_line,Num_total_node,OD_Kpath_set,new_total_line);
                        [objective,cost,total_travel_time,total_wait_time,total_invehicle_time,total_transfer_time,total_walk_time,fa1,fa2,fa3,fa4]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,walk_time);
                        if objective<=best_objective
                            value_temp=1;
                            best_objective=objective;
                            best_bus_frequency=current_bus_frequency;
                            best_N_bus=current_N_bus;
                            best_cost=cost;
                            best_total_travel_time=total_travel_time;
                            best_total_wait_time=total_wait_time;
                            best_total_invehicle_time=total_invehicle_time;
                            best_total_transfer_time=total_transfer_time;
                            best_total_walk_time=total_walk_time;
                            best_fa1=fa1;
                            best_fa2=fa2;
                            best_fa3=fa3;
                            best_fa4=fa4;
                        else
                            current_N_bus(1,i)=current_N_bus(1,i)+1;
                            current_N_bus(1,j)=current_N_bus(1,j)-1;
                            current_bus_frequency(1,i)=floor(current_N_bus(1,i)/(2*time_bus_line(1,i)));
                            current_bus_frequency(1,j)=floor(current_N_bus(1,j)/(2*time_bus_line(1,j)));
                            j=j+1;
                        end
                    end
                end%end if
            else%%if increase_node(i,j)>=1
                j=j+1;
            end%if increase_node(i,j)>=1
            i;
            j;
            value_temp;
            current_N_bus;
            current_bus_frequency;
        end%while j
        %***********************
        i=i+1;
        %****************************************
    else
        i=i+1;
    end%if
end%while i

Objective=best_objective;
Cost=best_cost;
Total_travel_time=best_total_travel_time;
Total_wait_time=best_total_wait_time;
Total_invehicle_time=best_total_invehicle_time;
Total_transfer_time=best_total_transfer_time;
Total_walk_time=best_total_walk_time;
Fa1=best_fa1;
Fa2=best_fa2;
Fa3=best_fa3;
Fa4=best_fa4;
Num_bus=best_N_bus;
Bus_frequency=best_bus_frequency;


