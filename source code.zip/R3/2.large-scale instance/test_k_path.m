%检验K短路是否有在同一个点处连续换乘的情况：在同一节点有两个换乘弧，这样的路径是不正确的；这个程序不能排除有两个连续步行弧的情况
function value=test_k_path(path,new_total_line,Num_total_line)
global N_platform
walk_line=[1:N_platform];
arc_transfer_temp=[];%总的换乘弧
for i=2:size(path,2)-2%在对节点进行扩展后，一条路径至少有4个节点
    location_line_i=0;
    location_line_i_nextnode=0;
    if ismember(path(1,i),walk_line)%从i=2开始
        location_line_i=0;
    else
        for n=1:Num_total_line
            if ismember(path(1,i),new_total_line{1,n}(1,:))
                location_line_i=n;%寻找节点i所在的线路
            end
        end
    end
    if ismember(path(1,i+1),walk_line)%从i=2开始
        location_line_i_nextnode=0;
    else
        for n=1:Num_total_line
            if ismember(path(1,i+1),new_total_line{1,n}(1,:))
                location_line_i_nextnode=n;%寻找节点i所在的线路
            end
        end
    end 
    %总的换乘弧
    if location_line_i~=location_line_i_nextnode
        arc_transfer_temp=[arc_transfer_temp,path(1,i),path(1,i+1)];
    end
end
arc_transfer_temp1=unique(arc_transfer_temp);
if size(arc_transfer_temp,2)==0
    value=1;
else
    if size(arc_transfer_temp1,2)==size(arc_transfer_temp,2)
        value=1;
    else
        value=0;
    end
end




