function [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_objective,new_cost,new_travel_time,new_wait_time,new_invehicle_time,new_transfer_time,new_walk_time,new_fa1,new_fa2,new_fa3,new_fa4,new_Num_bus,new_Bus_frequency]=operator6(currentbest_bus_line)
global N_platform  KK OD  Bus_station
global trunk_matrix length_trunk_matrix
global main_feeder_matrix length_main_feeder_matrix road_matrix length_road_matrix
global currentbest_objective currentbest_cost currentbest_total_travel_time currentbest_total_wait_time currentbest_total_invehicle_time currentbest_total_transfer_time currentbest_total_walk_time currentbest_fa1 currentbest_fa2 currentbest_fa3 currentbest_fa4 currentbest_Num_bus  currentbest_bus_frequency
trunk_line=currentbest_bus_line{1,1};
main_line=currentbest_bus_line{1,2};
feeder_line=currentbest_bus_line{1,3};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
delete_line=[];
if num_trunk_line>0
    delete_line=[delete_line,1];
end
if num_main_line>0
    delete_line=[delete_line,2];
end
if num_feeder_line>0
    delete_line=[delete_line,3];
end

delete_kind=delete_line(1,ceil(rand*size(delete_line,2)));
if delete_kind==1
    n1=ceil(rand*num_trunk_line);
    n2=round(rand);
    bus_line_temp=trunk_line{1,n1};
    delete_position=1+ceil(rand*(size(bus_line_temp,2)-2));
    if size(bus_line_temp,2)>2
        if n2==0
            bus_line_temp=bus_line_temp(1,delete_position+1:size(bus_line_temp,2));
        else
            bus_line_temp=bus_line_temp(1,1:delete_position-1);
        end
    else
        if size(bus_line_temp,2)==2
            if n2==0
                bus_line_temp=bus_line_temp(1,2);
            else
                bus_line_temp=bus_line_temp(1,1);
            end
        end
    end
else
    if delete_kind==2
        n1=ceil(rand*num_main_line);
        n2=round(rand);
        bus_line_temp=main_line{1,n1};
        delete_position=1+ceil(rand*(size(bus_line_temp,2)-2));
        if n2==0
            bus_line_temp=bus_line_temp(1,delete_position+1:size(bus_line_temp,2));
        else
            bus_line_temp=bus_line_temp(1,1:delete_position-1);
        end
    else
        if delete_kind==3
            n1=ceil(rand*num_feeder_line);
            bus_line_temp=feeder_line{1,n1};
            delete_position=1+ceil(rand*(size(bus_line_temp,2)-2));
            bus_line_temp=bus_line_temp(1,1:delete_position-1);
        end
    end
end
currentbest_bus_line_temp=currentbest_bus_line;
currentbest_bus_line_temp{1,delete_kind}={currentbest_bus_line{1,delete_kind}{1,1:n1-1},currentbest_bus_line{1,delete_kind}{1,n1+1:size(currentbest_bus_line{1,delete_kind},2)}};
new_bus_line_temp=bus_line_temp;
if delete_kind==1
    n2=round(rand);
    if n2==0
        position=1;
    else
        position=size(bus_line_temp,2);
    end
    s=bus_line_temp(1,position);
    inter_node=[];
    for g=1:size(bus_line_temp,2)-1
        i=bus_line_temp(1,g);
        j=bus_line_temp(1,g+1);
        [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
        inter_node=[inter_node,shortest_path_temp(1,2:size(shortest_path_temp,2)-1)];
    end
    actual_route=[bus_line_temp,inter_node];
    actual_route_temp=unique(actual_route);
    rest=setdiff(Bus_station,actual_route_temp,'stable');
    rest_temp=randperm(size(rest,2));
    for i=1:size(rest,2)
        e=rest(1,rest_temp(1,i));
        [add_path_temp,length_path_temp]=Kshortest_line(trunk_matrix,length_trunk_matrix,s,e);
        for k=1:KK
            if n2==0
                add_path_temp{1,k}=fliplr(add_path_temp{1,k});
                new_bus_line_temp=[add_path_temp{1,k}(1,1:size(add_path_temp{1,k},2)-1),bus_line_temp];
            else
                new_bus_line_temp=[bus_line_temp,add_path_temp{1,k}(1,2:size(add_path_temp{1,k},2))];
            end
            length_bus_line_temp=0;
            for j=1:size(new_bus_line_temp,2)-1
                length_bus_line_temp=length_bus_line_temp+length_trunk_matrix(new_bus_line_temp(1,j),new_bus_line_temp(1,j+1));
            end
            value_length=judge_length(length_bus_line_temp,delete_kind);
            value_loop=judge_loop(new_bus_line_temp);
            value_zhefan=judge_zhefan(new_bus_line_temp);
            if value_length==1&&value_loop==1&&value_zhefan==1
                break
            end
        end
        if value_length==1&&value_loop==1&&value_zhefan==1
            break
        end
        if value_length==0||value_loop==0||value_zhefan==0
            new_bus_line_temp=trunk_line{1,n1};
        end
    end
else
    if delete_kind==2
        n2=round(rand);
        if n2==0
            position=1;
        else
            position=size(bus_line_temp,2);
        end
        s=bus_line_temp(1,position);
        inter_node=[];
        for g=1:size(bus_line_temp,2)-1
            i=bus_line_temp(1,g);
            j=bus_line_temp(1,g+1);
            [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
            inter_node=[inter_node,shortest_path_temp(1,2:size(shortest_path_temp,2)-1)];
        end
        actual_route=[bus_line_temp,inter_node];
        actual_route_temp=unique(actual_route);
        rest=setdiff(Bus_station,actual_route_temp,'stable');
        rest_temp=randperm(size(rest,2));
        for i=1:size(rest,2)
            e=rest(1,rest_temp(1,i));
            [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
            for k=1:KK
                if n2==0
                    add_path_temp{1,k}=fliplr(add_path_temp{1,k});
                    new_bus_line_temp=[add_path_temp{1,k}(1,1:size(add_path_temp{1,k},2)-1),bus_line_temp];
                else
                    new_bus_line_temp=[bus_line_temp,add_path_temp{1,k}(1,2:size(add_path_temp{1,k},2))];
                end
                length_bus_line_temp=0;
                for j=1:size(new_bus_line_temp,2)-1
                    length_bus_line_temp=length_bus_line_temp+length_main_feeder_matrix(new_bus_line_temp(1,j),new_bus_line_temp(1,j+1));
                end
                value_length=judge_length(length_bus_line_temp,delete_kind);
                value_loop=judge_loop(new_bus_line_temp);
                value_zhefan=judge_zhefan(new_bus_line_temp);
                if value_length==1&&value_loop==1&&value_zhefan==1
                    break
                end
            end
            if value_length==1&&value_loop==1&&value_zhefan==1
                break
            end
            if value_length==0||value_loop==0||value_zhefan==1
                new_bus_line_temp=main_line{1,n1};
            end
        end
    else
        if delete_kind==3
            position=size(bus_line_temp,2);
            s=bus_line_temp(1,position);
            inter_node=[];
            for g=1:size(bus_line_temp,2)-1
                i=bus_line_temp(1,g);
                j=bus_line_temp(1,g+1);
                [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
                inter_node=[inter_node,shortest_path_temp(1,2:size(shortest_path_temp,2)-1)];
            end
            actual_route=[bus_line_temp,inter_node];
            actual_route_temp=unique(actual_route);
            rest=setdiff(Bus_station,actual_route_temp,'stable');
            rest_temp=randperm(size(rest,2));
            for i=1:size(rest,2)
                e=rest(1,rest_temp(1,i));
                [add_path_temp,length_path_temp]=Kshortest_line(main_feeder_matrix,length_main_feeder_matrix,s,e);
                for k=1:KK
                    new_bus_line_temp=[bus_line_temp,add_path_temp{1,k}(1,2:size(add_path_temp{1,k},2))];
                    length_bus_line_temp=0;
                    for j=1:size(new_bus_line_temp,2)-1
                        length_bus_line_temp=length_bus_line_temp+length_main_feeder_matrix(new_bus_line_temp(1,j),new_bus_line_temp(1,j+1));
                    end
                    value_length=judge_length(length_bus_line_temp,delete_kind);
                    value_loop=judge_loop(new_bus_line_temp);
                    value_zhefan=judge_zhefan(new_bus_line_temp);
                    if value_length==1&&value_loop==1&&value_zhefan==1
                        break
                    end
                end
                if value_length==1&&value_loop==1&&value_zhefan==1
                    break
                end
                if value_length==0||value_loop==0||value_zhefan==1
                    new_bus_line_temp=feeder_line{1,n1};
                end
            end
        end
    end
end
if delete_kind==1
    trunk_line{1,n1}=new_bus_line_temp;
else
    if delete_kind==2
        main_line{1,n1}=new_bus_line_temp;
    else
        if delete_kind==3
            feeder_line{1,n1}=new_bus_line_temp;
        end
    end
end
value_contain=judge_contain(new_bus_line_temp,currentbest_bus_line_temp,delete_kind);
[value_stop_line,plat_line_bus]=judge_stop_line(trunk_line,main_line,feeder_line);
if value_contain==1&&value_stop_line==1
    [Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
    [OD_Kpath_set,original_line,inline_transfer,arc,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);
    value_connection_temp=ones(N_platform,N_platform);
    for s=1:N_platform
        for e=1:N_platform
            if e~=s&&OD(s,e)~=0
                if ismember(inf,OD_Kpath_set{s,e}{1,1})
                    value_connection_temp(s,e)=0;
                end
            end
        end
    end
    if ismember(0,value_connection_temp)
        value_connection=0;
    else
        value_connection=1;
    end
    if value_connection==1
        value_update=1;
        new_trunk_line=trunk_line;
        new_main_line=main_line;
        new_feeder_line=feeder_line;
        new_num_trunk_line=size(new_trunk_line,2);
        new_num_main_line=size(new_main_line,2);
        new_num_feeder_line=size(new_feeder_line,2);
        new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
        [new_objective,new_cost,new_travel_time,new_wait_time,new_invehicle_time,new_transfer_time,new_walk_time,new_fa1,new_fa2,new_fa3,new_fa4,new_Num_bus,new_Bus_frequency]=cal_objective_frequency(Num_total_line,new_num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer);
    else
        value_update=0;
        new_trunk_line=currentbest_bus_line{1,1};
        new_main_line=currentbest_bus_line{1,2};
        new_feeder_line=currentbest_bus_line{1,3};
        new_num_trunk_line=size(new_trunk_line,2);
        new_num_main_line=size(new_main_line,2);
        new_num_feeder_line=size(new_feeder_line,2);
        new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
        new_objective=currentbest_objective;
        new_cost=currentbest_cost;
        new_travel_time=currentbest_total_travel_time;
        new_wait_time=currentbest_total_wait_time;
        new_invehicle_time=currentbest_total_invehicle_time;
        new_transfer_time=currentbest_total_transfer_time;
        new_walk_time=currentbest_total_walk_time;
        new_fa1=currentbest_fa1;
        new_fa2=currentbest_fa2;
        new_fa3=currentbest_fa3;
        new_fa4=currentbest_fa4;
        new_Num_bus=currentbest_Num_bus;
        new_Bus_frequency=currentbest_bus_frequency;
    end
else
    value_update=0;
    new_trunk_line=currentbest_bus_line{1,1};
    new_main_line=currentbest_bus_line{1,2};
    new_feeder_line=currentbest_bus_line{1,3};
    new_num_trunk_line=size(new_trunk_line,2);
    new_num_main_line=size(new_main_line,2);
    new_num_feeder_line=size(new_feeder_line,2);
    new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
    new_objective=currentbest_objective;
    new_cost=currentbest_cost;
    new_travel_time=currentbest_total_travel_time;
    new_wait_time=currentbest_total_wait_time;
    new_invehicle_time=currentbest_total_invehicle_time;
    new_transfer_time=currentbest_total_transfer_time;
    new_walk_time=currentbest_total_walk_time;
    new_fa1=currentbest_fa1;
    new_fa2=currentbest_fa2;
    new_fa3=currentbest_fa3;
    new_fa4=currentbest_fa4;
    new_Num_bus=currentbest_Num_bus;
    new_Bus_frequency=currentbest_bus_frequency;
end
































