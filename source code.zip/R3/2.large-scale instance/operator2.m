%delete
function [new_trunk_line,new_main_line,new_feeder_line,new_num_bus_line,value_update,new_objective,new_cost,new_travel_time,new_wait_time,new_invehicle_time,new_transfer_time,new_walk_time,new_fa1,new_fa2,new_fa3,new_fa4,new_Num_bus,new_Bus_frequency]=operator2(currentbest_bus_line)
global currentbest_objective currentbest_cost currentbest_total_travel_time currentbest_total_wait_time currentbest_total_invehicle_time currentbest_total_transfer_time currentbest_total_walk_time currentbest_fa1 currentbest_fa2 currentbest_fa3 currentbest_fa4 currentbest_Num_bus  currentbest_bus_frequency
global N_platform OD
trunk_line=currentbest_bus_line{1,1};
main_line=currentbest_bus_line{1,2};
feeder_line=currentbest_bus_line{1,3};
num_trunk_line=size(trunk_line,2);
num_main_line=size(main_line,2);
num_feeder_line=size(feeder_line,2);
delete_line=[];
if num_trunk_line>0
    delete_line=[delete_line,1];
end
if num_main_line>0
    delete_line=[delete_line,2];
end
if num_feeder_line>0
    delete_line=[delete_line,3];
end
delete_position=ceil(rand*size(delete_line,2));
delete_kind=delete_line(1,delete_position);
if delete_kind==1
    n=ceil(rand*num_trunk_line);
    if n==1
        trunk_line={trunk_line{1,n+1:num_trunk_line}};
    else
        if n==num_trunk_line
            trunk_line={trunk_line{1,1:n-1}};
        else
            trunk_line={trunk_line{1,1:n-1},trunk_line{1,n+1:num_trunk_line}};
        end
    end
else
    if delete_kind==2
        n=ceil(rand*num_main_line);
        if n==1
            main_line={main_line{1,n+1:num_main_line}};
        else
            if n==num_main_line
                main_line={main_line{1,1:n-1}};
            else
                main_line={main_line{1,1:n-1},main_line{1,n+1:num_main_line}};
            end
        end
    else
        if delete_kind==3
            n=ceil(rand*num_feeder_line);
            if n==1
                feeder_line={feeder_line{1,n+1:num_feeder_line}};
            else
                if n==num_feeder_line
                    feeder_line={feeder_line{1,1:n-1}};
                else
                    feeder_line={feeder_line{1,1:n-1},feeder_line{1,n+1:num_feeder_line}};
                end
            end
        end
    end
end
[Num_total_line,total_line,length_bus_line,time_bus_line,Num_total_node,new_total_line,new_bimodal_network,Time_new_bimodal_network,Length_new_bimodal_network,plat_line,plat_line_node,plat_line_bus]=update_bimodal_network(trunk_line,main_line,feeder_line);
[OD_Kpath_set,original_line,inline_transfer,arc,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer]=cal_kpath(Num_total_line,total_line,new_total_line,new_bimodal_network,Time_new_bimodal_network,plat_line,plat_line_node);    
value_connection_temp=ones(N_platform,N_platform);
for s=1:N_platform
    for e=1:N_platform
        if e~=s&&OD(s,e)~=0
            if ismember(inf,OD_Kpath_set{s,e}{1,1})
                value_connection_temp(s,e)=0;
            end
        end
    end
end
if ismember(0,value_connection_temp)
    value_connection=0;
else
    value_connection=1;
end
if value_connection==1
    value_update=1;
    new_trunk_line=trunk_line;
    new_main_line=main_line;
    new_feeder_line=feeder_line;
    new_num_trunk_line=size(new_trunk_line,2);
    new_num_main_line=size(new_main_line,2);
    new_num_feeder_line=size(new_feeder_line,2);
    new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
    [new_objective,new_cost,new_travel_time,new_wait_time,new_invehicle_time,new_transfer_time,new_walk_time,new_fa1,new_fa2,new_fa3,new_fa4,new_Num_bus,new_Bus_frequency]=cal_objective_frequency(Num_total_line,new_num_bus_line,Num_total_node,new_total_line,OD_Kpath_set,length_bus_line,time_bus_line,Length_new_bimodal_network,Time_new_bimodal_network,original_line,inline_transfer,line_arc,arc_walk,invehicle_arc,invehicle_arc_line,arc_transfer_non_walk,arc_transfer_walk,Num_transfer);
else
    value_update=0;
    new_trunk_line=currentbest_bus_line{1,1};
    new_main_line=currentbest_bus_line{1,2};
    new_feeder_line=currentbest_bus_line{1,3};
    new_num_trunk_line=size(new_trunk_line,2);
    new_num_main_line=size(new_main_line,2);
    new_num_feeder_line=size(new_feeder_line,2);
    new_num_bus_line=new_num_trunk_line+new_num_main_line+new_num_feeder_line;
    new_objective=currentbest_objective;
    new_cost=currentbest_cost;
    new_travel_time=currentbest_total_travel_time;
    new_wait_time=currentbest_total_wait_time;
    new_invehicle_time=currentbest_total_invehicle_time;
    new_transfer_time=currentbest_total_transfer_time;
    new_walk_time=currentbest_total_walk_time;
    new_fa1=currentbest_fa1;
    new_fa2=currentbest_fa2;
    new_fa3=currentbest_fa3;
    new_fa4=currentbest_fa4;
    new_Num_bus=currentbest_Num_bus;
    new_Bus_frequency=currentbest_bus_frequency;
end


