function value=judge_length(length_shortest_path_temp,add_kind)      
global Max_length_trunk  Min_length_trunk
global Max_length_main Min_length_main
global Max_length_feeder Min_length_feeder
value=0;
if add_kind==1
    if length_shortest_path_temp<=Max_length_trunk&&length_shortest_path_temp>=Min_length_trunk
        value=1;
    end
else
    if add_kind==2
        if length_shortest_path_temp<=Max_length_main&&length_shortest_path_temp>=Min_length_main
            value=1;
        end
    else
        if add_kind==3
            if length_shortest_path_temp<=Max_length_feeder&&length_shortest_path_temp>=Min_length_feeder
                value=1;
            end
        end
    end
end