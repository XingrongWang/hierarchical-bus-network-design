function [trunk_matrix,length_trunk_matrix,time_trunk_matrix]=generate_trunk
global N_platform road_matrix length_road_matrix v_bus_rapid
max_limit_trunk=8;
min_limit_trunk=2;
trunk_matrix=zeros(N_platform,N_platform);
length_trunk_matrix=zeros(N_platform,N_platform);
time_trunk_matrix=zeros(N_platform,N_platform);
for i=1:N_platform
    for j=i+1:N_platform
        [shortest_path_temp,length_path_temp]=shortest_path(road_matrix,length_road_matrix,i,j);
        if length_path_temp<=max_limit_trunk&&length_path_temp>min_limit_trunk
            length_trunk_matrix(i,j)=length_path_temp;
            time_trunk_matrix(i,j)=length_path_temp/v_bus_rapid;%unit:hour
        end
    end
end
for i=1:N_platform
    for j=i+1:N_platform
        distance=max(length_trunk_matrix(i,j),length_trunk_matrix(j,i));
        length_trunk_matrix(i,j)=distance;
        length_trunk_matrix(j,i)=distance;
        time=max(time_trunk_matrix(i,j),time_trunk_matrix(j,i));
        time_trunk_matrix(i,j)=time;
        time_trunk_matrix(j,i)=time;
        if distance>0
        trunk_matrix(i,j)=1;
        trunk_matrix(j,i)=1;
        end
    end
end       
for i=1:N_platform
    for j=1:N_platform
        if trunk_matrix(i,j)==0
            length_trunk_matrix(i,j)=10000;
            time_trunk_matrix(i,j)=10000;
        end
    end
end
     