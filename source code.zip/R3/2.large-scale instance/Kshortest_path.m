function [k_shortest_path,k_time_path,original_line_temp,inline_transfer_temp,arc_temp,line_arc_temp,arc_walk_temp,invehicle_arc_temp,invehicle_arc_line_temp,arc_transfer_non_walk_temp,arc_transfer_walk_temp,Num_transfer_temp]=Kshortest_path(A,weight,s,e,Num_total_line,new_total_line,plat_line,total_line,plat_line_node)
%输出的是OD对se的K条有效路径以及相应的属性:按换乘次数筛选最短路，换乘次数相等的，按时间进行排序，筛选出K条
% A=new_bimodal_network
% weight=Time_new_bimodal_network
% s=31
% e=21
global K N_platform
global Num_transfer_allow cofficient
k_shortest_path=cell(1,K);
k_time_path=zeros(1,K);
original_line_temp=zeros(1,K);
inline_transfer_temp=cell(1,K);
arc_temp=cell(1,K);
line_arc_temp=cell(1,K);
arc_walk_temp=cell(1,K);
invehicle_arc_temp=cell(1,K);
invehicle_arc_line_temp=cell(1,K);
arc_transfer_non_walk_temp=cell(1,K);
arc_transfer_walk_temp=cell(1,K);
Num_transfer_temp=zeros(1,K);
%******************************
Kmax=6;%寻找的最大的路径数量，其中包含在站台处连乘的线路和不满足要求的线路
k_shortest_path1=cell(1,Kmax);
k_time_path1=zeros(1,Kmax);
weight_temp=weight;
for i=1:N_platform
    if i~=s&&i~=e
        for j=1:size(plat_line{1,i},2)
            weight_temp(i,plat_line_node{1,i}(1,j))=10000;
            weight_temp(plat_line_node{1,i}(1,j),i)=10000;
            for jj=j+1:size(plat_line{1,i},2)
                weight_temp(plat_line_node{1,i}(1,j),plat_line_node{1,i}(1,jj))=10000;%防止过多换乘次数的路径被搜到,后续可以计算线路上的换乘次数？
                weight_temp(plat_line_node{1,i}(1,jj),plat_line_node{1,i}(1,j))=10000;
            end
        end
    end
end
%判断是否联通，若不联通，无需后面的操作；若联通，先找出Kmax条联通的路径，再判断是否有满足要求的，若没有，则
[shortest_path_temp,time_shortest_path]=shortest_path(A,weight_temp,s,e);%网络联通的情况下，每个od都能找到最短路，只不过有的换乘次数比较多，对于初始解而言，对于路径不满足有效路径的od来说，应该施加惩罚
k=1;
while k<=Kmax
    if k==1
        [k_shortest_path1{1,k},k_time_path1(1,k)]=shortest_path(A,weight_temp,s,e);%不一定能找到最短路（网络不联通的情况下）
    else
        n_node=size(k_shortest_path1{1,k-1}(1,:),2);
        if mod(n_node,2)==0
            weight_temp(k_shortest_path1{1,k-1}(1,n_node/2),k_shortest_path1{1,k-1}(1,n_node/2+1))=inf;
        else
            weight_temp(k_shortest_path1{1,k-1}(1,(n_node+1)/2-1),k_shortest_path1{1,k-1}(1,(n_node+1)/2))=inf;
        end
        [k_shortest_path1{1,k},k_time_path1(1,k)]=shortest_path(A,weight_temp,s,e);
    end
    k=k+1;
end
value=zeros(1,Kmax);
for k=1:Kmax
    value(1,k)=test_k_path(k_shortest_path1{1,k},new_total_line,Num_total_line);%是否存在连续换乘
end
position=find(value==0);
k_shortest_path1(position)=[];
k_time_path1(position)=[];
Kmax1=size(k_shortest_path1,2);

original_line_temp1=zeros(1,Kmax1);
inline_transfer_temp1=cell(1,Kmax1);
arc_temp1=cell(1,Kmax1);
line_arc_temp1=cell(1,Kmax1);
arc_walk_temp1=cell(1,Kmax1);
invehicle_arc_temp1=cell(1,Kmax1);
invehicle_arc_line_temp1=cell(1,Kmax1);
arc_transfer_non_walk_temp1=cell(1,Kmax1);
arc_transfer_walk_temp1=cell(1,Kmax1);
Num_transfer_temp1=zeros(1,Kmax1);
k=1;
while k<=Kmax1
    if k==1
        [original_line_temp1(1,k),inline_transfer_temp1{1,k},arc_temp1{1,k},line_arc_temp1{1,k},arc_walk_temp1{1,k},invehicle_arc_temp1{1,k},invehicle_arc_line_temp1{1,k},arc_transfer_non_walk_temp1{1,k},arc_transfer_walk_temp1{1,k},Num_transfer_temp1(1,k)]=calculate_path_attribute(k_shortest_path1{1,k},Num_total_line,new_total_line); 
    else
        if k_time_path1(1,k)==inf%说明没有最短路
            k_time_path1(1,k)=k_time_path1(1,1);
            k_shortest_path1{1,k}=k_shortest_path1{1,1};
            original_line_temp1(1,k)=original_line_temp1(1,1);
            inline_transfer_temp1{1,k}=inline_transfer_temp1{1,1};
            arc_temp1{1,k}=arc_temp1{1,1};
            line_arc_temp1{1,k}=line_arc_temp1{1,1};
            arc_walk_temp1{1,k}=arc_walk_temp1{1,1};
            invehicle_arc_temp1{1,k}=invehicle_arc_temp1{1,1};
            invehicle_arc_line_temp1{1,k}=invehicle_arc_line_temp1{1,1};
            arc_transfer_non_walk_temp1{1,k}=arc_transfer_non_walk_temp1{1,1};
            arc_transfer_walk_temp1{1,k}=arc_transfer_walk_temp1{1,1};
            Num_transfer_temp1(1,k)=Num_transfer_temp1(1,1);
        else
            [original_line_temp1(1,k),inline_transfer_temp1{1,k},arc_temp1{1,k},line_arc_temp1{1,k},arc_walk_temp1{1,k},invehicle_arc_temp1{1,k},invehicle_arc_line_temp1{1,k},arc_transfer_non_walk_temp1{1,k},arc_transfer_walk_temp1{1,k},Num_transfer_temp1(1,k)]=calculate_path_attribute(k_shortest_path1{1,k},Num_total_line,new_total_line); 
        end
    end
    k=k+1;
end
%把相同的线路剔除
same_line=cell(1,Kmax1);%每个元胞中存储和k线路相同的线路编号
for k=1:Kmax1
    same_line{1,k}=[];
    for i=k+1:Kmax1
        if isequal(k_shortest_path1{1,i},k_shortest_path1{1,k})
            same_line{1,k}=[same_line{1,k},i];
        end
    end
end
same_position=[];
for k=Kmax1:-1:1
    for i=1:Kmax1
        if ismember(k,same_line{1,i})
            same_position=[same_position,k];
        end
    end
end
same_position=unique(same_position);
k_time_path1(same_position)=[];
k_shortest_path1(same_position)=[];
original_line_temp1(same_position)=[];
inline_transfer_temp1(same_position)=[];
arc_temp1(same_position)=[];
line_arc_temp1(same_position)=[];
arc_walk_temp1(same_position)=[];
invehicle_arc_temp1(same_position)=[];
invehicle_arc_line_temp1(same_position)=[];
arc_transfer_non_walk_temp1(same_position)=[];
arc_transfer_walk_temp1(same_position)=[];
Num_transfer_temp1(same_position)=[];
%换乘次数+时间+换乘模式有效性
Kmax2=size(k_shortest_path1,2);
k_shortest_path_set={};
time_k_shortest_path_set=[];
position_k_shortest_path_set=[];
Num_transfer_set=[];
%计算实际的最短路时间以及各路径对应的实际的时间
[shortest_path_temp,time_shortest_path]=shortest_path(A,weight,s,e);%不一定能找到最短路（网络不联通的情况下）
real_time=zeros(1,Kmax2);%存储实际的出行时间
for k=1:Kmax2
    for i=1:size(k_shortest_path1{1,k},2)-1
        real_time(1,k)=real_time(1,k)+weight(k_shortest_path1{1,k}(1,i),k_shortest_path1{1,k}(1,i+1));
    end
end
for k=1:Kmax2
    if Num_transfer_temp1(1,k)<=Num_transfer_allow&&real_time(1,k)<=cofficient*time_shortest_path
        value=judge_transfer(Num_transfer_temp1(1,k),line_arc_temp1{1,k},invehicle_arc_line_temp1{1,k},Num_total_line);%判断有效换乘
        if value==1
        position_k_shortest_path_set=[position_k_shortest_path_set,k];%元素取值是多少k，就是第k条线路[3 5 6]:第3、5、6条线路
        k_shortest_path_set=[k_shortest_path_set,k_shortest_path1{1,k}];
        time_k_shortest_path_set=[time_k_shortest_path_set,real_time(1,k)];%此时的时间是实际的时间
        Num_transfer_set=[Num_transfer_set,Num_transfer_temp1(1,k)];
        end
    end
end
%对换乘次数进行排序，换乘次数相等的按time进行排序，最后取前K，（1）如果满足要求的数量<K,则用第一条进行填充
[Num_transfer_set_new1,rank_position1]=sort(Num_transfer_set);%rank_position1中的第i个元素的取值是k表示的是在k_shortest_path_set中的第k条线路
number_transfer0=[];%0次换乘
number_transfer1=[];%1次换乘的线路编号
number_transfer2=[];%2次换乘的线路编号
number_transfer3=[];%3次换乘换乘的线路编号
time_transfer0=[];
time_transfer1=[];%1次换乘的线路编号对应的time
time_transfer2=[];%2次换乘的线路编号对应的time
time_transfer3=[];%3次换乘换乘的线路编号对应的time
for i=1:size(Num_transfer_set_new1,2)
    if Num_transfer_set_new1(1,i)==0
        number_transfer0=[number_transfer0,rank_position1(1,i)];%元素取值为几，就表示k_shortest_path_set中的第i条线路【3 5 8】【0.2 0.1 0.4】
        time_transfer0=[time_transfer0,time_k_shortest_path_set(1,rank_position1(1,i))];
    else
        if Num_transfer_set_new1(1,i)==1
            number_transfer1=[number_transfer1,rank_position1(1,i)];%元素取值为几，就表示k_shortest_path_set中的第i条线路【3 5 8】【0.2 0.1 0.4】
            time_transfer1=[time_transfer1,time_k_shortest_path_set(1,rank_position1(1,i))];
        else
            if Num_transfer_set_new1(1,i)==2
                number_transfer2=[number_transfer2,rank_position1(1,i)];
                time_transfer2=[time_transfer2,time_k_shortest_path_set(1,rank_position1(1,i))];
            else
                if Num_transfer_set_new1(1,i)==3
                    number_transfer3=[number_transfer3,rank_position1(1,i)];
                    time_transfer3=[time_transfer3,time_k_shortest_path_set(1,rank_position1(1,i))];
                end
            end
        end
    end
end
%对相同换乘次数的线路按照线路time进行排序
[rank_time0,rank_time_position0]=sort(time_transfer0);
[rank_time1,rank_time_position1]=sort(time_transfer1);
[rank_time2,rank_time_position2]=sort(time_transfer2);
[rank_time3,rank_time_position3]=sort(time_transfer3);%number_transfer3中
new_number_transfer0=number_transfer0;
new_number_transfer1=number_transfer1;
new_number_transfer2=number_transfer2;
new_number_transfer3=number_transfer3;
for i=1:size(number_transfer0,2)
    new_number_transfer0(1,i)=number_transfer0(1,rank_time_position0(1,i));
end
for i=1:size(number_transfer1,2)
    new_number_transfer1(1,i)=number_transfer1(1,rank_time_position1(1,i));
end
for i=1:size(number_transfer2,2)
    new_number_transfer2(1,i)=number_transfer2(1,rank_time_position2(1,i));
end
for i=1:size(number_transfer3,2)
    new_number_transfer3(1,i)=number_transfer3(1,rank_time_position3(1,i));
end
% 对符合要求的线路顺序进行组合
if Num_transfer_allow==2
    new_number_transfer=[new_number_transfer0,new_number_transfer1,new_number_transfer2];
else
    if Num_transfer_allow==3
        new_number_transfer=[new_number_transfer0,new_number_transfer1,new_number_transfer2,new_number_transfer3];
    end
end
if size(new_number_transfer,2)==0%没有符合要求的线路
    for k=1:K
        k_shortest_path{1,k}=[];
        k_time_path(1,k)=inf;
        original_line_temp(1,k)=0;
        inline_transfer_temp{1,k}=[];
        arc_temp{1,k}=[];
        line_arc_temp{1,k}=[];
        arc_walk_temp{1,k}=[];
        invehicle_arc_temp{1,k}=[];
        invehicle_arc_line_temp{1,k}=[];
        arc_transfer_non_walk_temp{1,k}=[];
        arc_transfer_walk_temp{1,k}=[];
        Num_transfer_temp(1,k)=0;      
    end
else
    if size(new_number_transfer,2)>=K
        for k=1:K
            k_shortest_path{1,k}=k_shortest_path_set{1,new_number_transfer(1,k)};
            k_time_path(1,k)=time_k_shortest_path_set(1,new_number_transfer(1,k));
        end
    else
        for k=1:size(new_number_transfer,2)
            k_shortest_path{1,k}=k_shortest_path_set{1,new_number_transfer(1,k)};
            k_time_path(1,k)=time_k_shortest_path_set(1,new_number_transfer(1,k));
        end
        for k=size(new_number_transfer,2)+1:K
            k_shortest_path{1,k}=k_shortest_path_set{1,new_number_transfer(1,1)};
            k_time_path(1,k)=time_k_shortest_path_set(1,new_number_transfer(1,1));
        end
    end
    for k=1:K
    [original_line_temp(1,k),inline_transfer_temp{1,k},arc_temp{1,k},line_arc_temp{1,k},arc_walk_temp{1,k},invehicle_arc_temp{1,k},invehicle_arc_line_temp{1,k},arc_transfer_non_walk_temp{1,k},arc_transfer_walk_temp{1,k},Num_transfer_temp(1,k)]=calculate_path_attribute(k_shortest_path{1,k},Num_total_line,new_total_line); 
    end
end








