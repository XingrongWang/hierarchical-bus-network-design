function [objective,cost,total_travel_time,total_wait_time,total_invehicle_time,total_transfer_time,total_walk_time,fa1,fa2,fa3,fa4]=cal_objective(new_total_line,invehicle_arc,Num_bus_line,length_bus_line,current_bus_frequency,travel_time,OD_Kpath_demand,route_demand_max,current_N_bus,N_bus_max,route_demand1,route_demand2,wait_time,invehicle_time,transfer_time,walk_time)
global cost_operation cost_max min_avg_load
global CAP_bus CAP_metro f_metro Num_metro_line
global N_platform  K OD
Z0=0;
Z0_1=0;
Z0_2=0;
Z0_3=0;
Z0_4=0;
fa1=0;
fa2=0;
fa3=0;
fa4=0;
for s=1:N_platform
    for e=1:N_platform
        if s~=e&&OD(s,e)~=0
            for k=1:K
                Z0=Z0+travel_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_1=Z0_1+wait_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_2=Z0_2+invehicle_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_3=Z0_3+transfer_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
                Z0_4=Z0_4+walk_time(s,e,k)*OD_Kpath_demand{s,e}(1,k);
            end
        end
    end
end  
cost=0;
avg_load=zeros(1,Num_bus_line);
for i=1:Num_bus_line
    cost=cost+2*current_bus_frequency(1,i)*length_bus_line(1,i)*cost_operation;
    fa2=fa2+999999*max((route_demand_max(1,i+Num_metro_line)-current_bus_frequency(1,i)*CAP_bus),0);
    fa3=fa3+999999*max(current_N_bus(1,i)-N_bus_max(1,i),0);
    avg_load(1,i)=(sum(route_demand1{1,i+Num_metro_line})+sum(route_demand2{1,i+Num_metro_line}))/(2*current_bus_frequency(1,i)*CAP_bus*(size(new_total_line{1,i+Num_metro_line},2)-1));
    fa4=fa4+999999*max(min_avg_load-avg_load(1,i),0);
end
for i=1:Num_metro_line
    fa2=fa2+999999*max(route_demand_max(1,i)-f_metro*CAP_metro,0);
end
fa1=999999*max(cost-cost_max,0);
objective=Z0+fa1+fa2+fa3+fa4;
total_travel_time=Z0;
total_wait_time=Z0_1;
total_invehicle_time=Z0_2;
total_transfer_time=Z0_3;
total_walk_time=Z0_4;